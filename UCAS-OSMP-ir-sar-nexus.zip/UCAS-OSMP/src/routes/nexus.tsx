import { createFileRoute } from "@tanstack/react-router";
import { Console } from "@/components/nexus/console";

export const Route = createFileRoute("/nexus")({
  head: () => ({
    meta: [
      { title: "IR–SAR Nexus Console — UCAS" },
      {
        name: "description",
        content:
          "Proof of concept for IR–SAR Nexus: uncertainty-aware fusion of infrared, electro-optical, SAR products, and LiDAR for civilian inspection.",
      },
      { property: "og:title", content: "IR–SAR Nexus Console — UCAS" },
      {
        property: "og:description",
        content:
          "Multi-sensor fusion replay with fault injection, track dossiers and assurance metrics.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: NexusPage,
});

function NexusPage() {
  return <Console />;
}
