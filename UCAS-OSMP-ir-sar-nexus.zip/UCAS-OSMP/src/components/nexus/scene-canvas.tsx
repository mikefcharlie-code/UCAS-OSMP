import { useRef, useSyncExternalStore } from "react";
import { radius95 } from "@/lib/nexus/format";
import { TRUTHS, WORLD_H, WORLD_W, bodyRight } from "@/lib/nexus/model";
import type { Layers } from "@/lib/nexus/store";
import { useFrame, useNexus } from "@/lib/nexus/store";
import type { SensorFamily, Track } from "@/lib/nexus/types";

function sy(y: number) {
  return WORLD_H - y;
}

function familyOn(layers: Layers, family: SensorFamily): boolean {
  if (family === "lwir") return layers.lwir;
  if (family === "eo") return layers.eo;
  if (family === "sar") return layers.sar;
  if (family === "lidar") return layers.lidar;
  if (family === "ms") return layers.ms;
  if (family === "rf") return layers.rf;
  return false;
}

function ellipsePoints(
  x: number,
  y: number,
  pxx: number,
  pxy: number,
  pyy: number,
  k: number,
): string {
  let l1: number;
  let l2: number;
  let ux: number;
  let uy: number;
  if (Math.abs(pxy) < 1e-6) {
    if (pxx >= pyy) {
      l1 = pxx;
      l2 = pyy;
      ux = 1;
      uy = 0;
    } else {
      l1 = pyy;
      l2 = pxx;
      ux = 0;
      uy = 1;
    }
  } else {
    const tr = pxx + pyy;
    const det = pxx * pyy - pxy * pxy;
    const disc = Math.sqrt(Math.max(0, (tr * tr) / 4 - det));
    l1 = tr / 2 + disc;
    l2 = Math.max(tr / 2 - disc, 0.01);
    ux = pxy;
    uy = l1 - pxx;
    const n = Math.hypot(ux, uy) || 1;
    ux /= n;
    uy /= n;
  }
  const a = Math.sqrt(Math.max(l1, 0.01) * k);
  const b = Math.sqrt(Math.max(l2, 0.01) * k);
  const px = -uy;
  const py = ux;
  const pts: string[] = [];
  for (let i = 0; i <= 40; i++) {
    const ang = (i / 40) * Math.PI * 2;
    const wx = x + a * Math.cos(ang) * ux + b * Math.sin(ang) * px;
    const wy = y + a * Math.cos(ang) * uy + b * Math.sin(ang) * py;
    pts.push(`${wx.toFixed(1)},${sy(wy).toFixed(1)}`);
  }
  return pts.join(" ");
}

const SHORT: Record<string, string> = {
  bridge: "B-14",
  washout: "W-03",
  substation: "S-02",
  debris: "D-07",
  seep: "L-11",
  culvert: "C-4",
  glint: "Glint",
  rf: "RF",
};

export function SceneCanvas() {
  const ref = useRef<SVGSVGElement>(null);
  const mounted = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );
  const frame = useFrame();
  const layers = useNexus((s) => s.layers);
  const selected = useNexus((s) => s.selectedTrackId);
  const selectedObs = useNexus((s) => s.selectedObsId);
  const withheld = useNexus((s) => s.withheld);
  const selectTrack = useNexus((s) => s.selectTrack);
  const selectObs = useNexus((s) => s.selectObs);
  const right = bodyRight(frame.pose.heading);

  const pick = (event: React.MouseEvent<SVGSVGElement>) => {
    const svg = ref.current;
    if (!svg) return;
    const point = svg.createSVGPoint();
    point.x = event.clientX;
    point.y = event.clientY;
    const matrix = svg.getScreenCTM();
    if (!matrix) return;
    const local = point.matrixTransform(matrix.inverse());
    const wx = local.x;
    const wy = WORLD_H - local.y;
    let best: Track | null = null;
    let bestD = 42;
    for (const tr of frame.tracks) {
      const age = frame.t - tr.lastSupport;
      if (tr.state === "coasting" && age > 20 && tr.id !== selected) continue;
      const d = Math.hypot(tr.x - wx, tr.y - wy);
      const reach = Math.max(26, Math.min(70, radius95(tr.pxx, tr.pxy, tr.pyy) * 0.45));
      if (d < reach && d < bestD) {
        best = tr;
        bestD = d;
      }
    }
    if (best) {
      selectTrack(best.id);
      return;
    }
    let obsId: string | null = null;
    let obsD = 30;
    for (const obs of frame.observations) {
      if (obs.family === "nav") continue;
      const d = Math.hypot(obs.x - wx, obs.y - wy);
      if (d < obsD) {
        obsId = obs.id;
        obsD = d;
      }
    }
    if (obsId) selectObs(obsId);
  };

  const river: string[] = [];
  for (let x = 0; x <= WORLD_W; x += 24)
    river.push(`${x},${sy(438 + Math.sin(x * 0.008) * 18 + 46)}`);
  for (let x = WORLD_W; x >= 0; x -= 24)
    river.push(`${x},${sy(438 + Math.sin(x * 0.008) * 18 - 46)}`);

  return (
    <svg
      ref={ref}
      viewBox={`0 0 ${WORLD_W} ${WORLD_H}`}
      preserveAspectRatio="xMidYMid meet"
      className="h-full w-full touch-none bg-nx-bg"
      role="img"
      aria-label="Riverbend corridor. Select a fused feature."
      onClick={pick}
    >
      <rect x="0" y="0" width={WORLD_W} height={WORLD_H} fill="var(--color-nx-land)" />
      {Array.from({ length: 10 }, (_, i) => (i + 1) * 100).map((x) => (
        <line
          key={`vx${x}`}
          x1={x}
          y1={0}
          x2={x}
          y2={WORLD_H}
          stroke="var(--color-nx-line)"
          strokeWidth="1"
        />
      ))}
      {Array.from({ length: 7 }, (_, i) => (i + 1) * 100).map((y) => (
        <line
          key={`hy${y}`}
          x1={0}
          y1={sy(y)}
          x2={WORLD_W}
          y2={sy(y)}
          stroke="var(--color-nx-line)"
          strokeWidth="1"
        />
      ))}
      <polygon points={river.join(" ")} fill="var(--color-nx-water)" />
      <line
        x1="80"
        y1={sy(360)}
        x2="240"
        y2={sy(360)}
        stroke="var(--color-nx-road)"
        strokeWidth="8"
      />
      <line
        x1="330"
        y1={sy(360)}
        x2="1000"
        y2={sy(360)}
        stroke="var(--color-nx-road)"
        strokeWidth="8"
      />
      <line
        x1="80"
        y1={sy(520)}
        x2="1000"
        y2={sy(520)}
        stroke="var(--color-nx-road)"
        strokeWidth="8"
      />
      <line
        x1="640"
        y1={sy(330)}
        x2="640"
        y2={sy(510)}
        stroke="var(--color-nx-primary)"
        strokeWidth="9"
        opacity="0.85"
      />
      <line
        x1="80"
        y1={sy(290)}
        x2="1000"
        y2={sy(290)}
        stroke="var(--color-nx-muted)"
        strokeWidth="1.5"
        strokeDasharray="6 6"
      />
      <rect
        x="860"
        y={sy(630)}
        width="50"
        height="40"
        fill="none"
        stroke="var(--color-nx-fg)"
        opacity="0.45"
      />
      <text
        x="90"
        y={sy(690)}
        fill="var(--color-nx-muted)"
        fontSize="14"
        fontFamily="IBM Plex Mono, ui-monospace, monospace"
      >
        STAGING
      </text>
      <text
        x="780"
        y={sy(660)}
        fill="var(--color-nx-muted)"
        fontSize="14"
        fontFamily="IBM Plex Mono, ui-monospace, monospace"
      >
        YARD
      </text>
      <text
        x="70"
        y={sy(455)}
        fill="var(--color-nx-muted)"
        fontSize="14"
        fontFamily="IBM Plex Mono, ui-monospace, monospace"
      >
        RIVERBEND
      </text>

      {layers.footprint ? (
        <g
          fill="none"
          stroke="var(--color-nx-muted)"
          strokeWidth="1.5"
          strokeDasharray="5 5"
          opacity="0.55"
        >
          <circle cx={frame.pose.x} cy={sy(frame.pose.y)} r="175" />
          <line
            x1={frame.pose.x}
            y1={sy(frame.pose.y)}
            x2={frame.pose.x + right.x * 175}
            y2={sy(frame.pose.y + right.y * 175)}
          />
        </g>
      ) : null}

      {layers.truth
        ? TRUTHS.map((truth) => (
            <g key={truth.id}>
              <path
                d={`M ${truth.x(frame.t)} ${sy(truth.y(frame.t)) - 7} l 7 7 l -7 7 l -7 -7 z`}
                fill="none"
                stroke="var(--color-nx-fg)"
                opacity="0.55"
              />
              <text
                x={truth.x(frame.t) + 10}
                y={sy(truth.y(frame.t)) - 8}
                fill="var(--color-nx-muted)"
                fontSize="13"
                fontFamily="IBM Plex Mono, ui-monospace, monospace"
              >
                {SHORT[truth.id] ?? truth.id}
              </text>
            </g>
          ))
        : null}

      {frame.observations.map((obs, index) => {
        if (obs.family === "nav" || obs.suppressed || !familyOn(layers, obs.family)) return null;
        const x = obs.x;
        const y = sy(obs.y);
        const hot = obs.id === selectedObs;
        const color = obs.usableForFusion ? "var(--color-nx-fg)" : "var(--color-nx-primary)";
        const dash = obs.usableForFusion ? undefined : "3 3";
        const s = hot ? 8 : 6;
        return (
          <g
            key={`${obs.id}-${index}`}
            stroke={color}
            fill="none"
            strokeWidth={hot ? 2.5 : 1.6}
            strokeDasharray={dash}
          >
            {obs.family === "lwir" ? <circle cx={x} cy={y} r={s} /> : null}
            {obs.family === "eo" ? <rect x={x - s} y={y - s} width={s * 2} height={s * 2} /> : null}
            {obs.family === "sar" ? (
              <path d={`M ${x} ${y - s} l ${s} ${s} l ${-s} ${s} l ${-s} ${-s} z`} />
            ) : null}
            {obs.family === "lidar" ? (
              <path d={`M ${x - s} ${y} H ${x + s} M ${x} ${y - s} V ${y + s}`} />
            ) : null}
            {obs.family === "ms" ? (
              <>
                <circle cx={x} cy={y} r={s} />
                <circle cx={x} cy={y} r={s * 0.45} />
              </>
            ) : null}
            {obs.family === "rf" ? <circle cx={x} cy={y} r={s + 2} /> : null}
          </g>
        );
      })}

      {layers.fused
        ? frame.tracks.map((tr) => {
            const age = frame.t - tr.lastSupport;
            if (tr.state === "coasting" && age > 20 && tr.id !== selected) return null;
            const active = tr.id === selected;
            const held = withheld[tr.id];
            const rfOnly = tr.families.length === 1 && tr.families[0] === "rf";
            const color =
              tr.state === "confirmed"
                ? "var(--color-nx-accent)"
                : tr.state === "degraded" || tr.conflict
                  ? "var(--color-nx-primary)"
                  : "var(--color-nx-muted)";
            const dashed =
              tr.state === "coasting" || tr.state === "tentative" || held ? "8 6" : undefined;
            return (
              <g key={tr.id} opacity={rfOnly ? 0.45 : tr.state === "coasting" ? 0.7 : 1}>
                {layers.naive &&
                (tr.state === "confirmed" || tr.state === "degraded") &&
                tr.supportCount > 1 ? (
                  <polyline
                    points={ellipsePoints(tr.nx, tr.ny, tr.npxx, tr.npxy, tr.npyy, 5.991)}
                    fill="none"
                    stroke="var(--color-nx-primary)"
                    strokeWidth="1.4"
                    strokeDasharray="4 5"
                    opacity="0.7"
                  />
                ) : null}
                <polyline
                  points={ellipsePoints(tr.x, tr.y, tr.pxx, tr.pxy, tr.pyy, 5.991)}
                  fill="none"
                  stroke={color}
                  strokeWidth={active ? 2.6 : 1.6}
                  strokeDasharray={dashed}
                />
                <circle cx={tr.x} cy={sy(tr.y)} r={active ? 5 : 3.5} fill={color} />
                {active ? (
                  <text
                    x={tr.x + 12}
                    y={sy(tr.y) - 12}
                    fill="var(--color-nx-fg)"
                    fontSize="16"
                    fontFamily="IBM Plex Sans, sans-serif"
                  >
                    {tr.hypotheses[0]?.label ?? tr.id} · 95%{" "}
                    {Math.round(radius95(tr.pxx, tr.pxy, tr.pyy))} m
                  </text>
                ) : null}
              </g>
            );
          })
        : null}

      <g
        transform={`translate(${frame.pose.x} ${sy(frame.pose.y)}) rotate(${(frame.pose.heading * 180) / Math.PI - 90})`}
      >
        <path
          d="M 16 0 L -10 7 L -6 0 L -10 -7 Z"
          fill="var(--color-nx-fg)"
          stroke="var(--color-nx-primary)"
          strokeWidth="1.2"
        />
      </g>

      <g stroke="var(--color-nx-fg)" fill="none" strokeWidth="1.6">
        <line x1="48" y1={sy(48)} x2="248" y2={sy(48)} />
        <line x1="48" y1={sy(54)} x2="48" y2={sy(42)} />
        <line x1="248" y1={sy(54)} x2="248" y2={sy(42)} />
      </g>
      <text
        x="48"
        y={sy(28)}
        fill="var(--color-nx-muted)"
        fontSize="13"
        fontFamily="IBM Plex Mono, ui-monospace, monospace"
      >
        200 m
      </text>
      <g stroke="var(--color-nx-fg)" fill="none" strokeWidth="1.6">
        <line x1={WORLD_W - 48} y1={sy(WORLD_H - 56)} x2={WORLD_W - 48} y2={sy(WORLD_H - 28)} />
        <path
          d={`M ${WORLD_W - 54} ${sy(WORLD_H - 46)} L ${WORLD_W - 48} ${sy(WORLD_H - 56)} L ${WORLD_W - 42} ${sy(WORLD_H - 46)}`}
        />
      </g>
      <text
        x={WORLD_W - 56}
        y={sy(WORLD_H - 68)}
        fill="var(--color-nx-muted)"
        fontSize="13"
        fontFamily="IBM Plex Mono, ui-monospace, monospace"
      >
        N
      </text>
    </svg>
  );
}
