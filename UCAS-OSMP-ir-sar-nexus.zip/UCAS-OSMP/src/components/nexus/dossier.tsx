import { useState } from "react";
import { fmtMeters, fmtPct, fmtTime, radius95, stateLabel } from "@/lib/nexus/format";
import { BUILD, PROFILE } from "@/lib/nexus/model";
import { useFrame, useNexus } from "@/lib/nexus/store";
import type { Observation, Track } from "@/lib/nexus/types";

function Pill({
  children,
  tone,
}: {
  children: string;
  tone: "accent" | "primary" | "muted" | "danger";
}) {
  const tones = {
    accent: "bg-nx-accent/15 text-nx-accent",
    primary: "bg-nx-primary/15 text-nx-primary",
    muted: "bg-nx-surface-2 text-nx-muted",
    danger: "bg-nx-danger/15 text-nx-danger",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

function toneFor(
  state: Track["state"],
  conflict: boolean,
): "accent" | "primary" | "muted" | "danger" {
  if (conflict || state === "degraded") return "primary";
  if (state === "confirmed") return "accent";
  return "muted";
}

function Stat({ label, value, note }: { label: string; value: string; note: string }) {
  return (
    <div className="rounded-md border border-nx-line bg-nx-bg px-3 py-2">
      <div className="text-xs uppercase tracking-wide text-nx-muted">{label}</div>
      <div className="mt-1 font-mono text-lg text-nx-fg tabular-nums">{value}</div>
      <div className="mt-1 text-xs leading-snug text-nx-muted">{note}</div>
    </div>
  );
}

function Envelope({ obs, onBack }: { obs: Observation; onBack: () => void }) {
  const rows: [string, string][] = [
    ["Schema", obs.schema],
    ["Record", obs.id],
    ["Sensor", `${obs.sensorId} · ${obs.family}`],
    ["Platform", obs.platformId],
    ["Acquire", `${fmtTime(obs.tAcquire)} · ±${(obs.timeUncertaintyS * 1000).toFixed(0)} ms`],
    ["Clock", obs.clockId],
    ["Receive", fmtTime(obs.tReceive)],
    ["Frame", obs.frame],
    ["Pose ref", obs.poseRef],
    ["Position", `${obs.x.toFixed(1)} E, ${obs.y.toFixed(1)} N m`],
    [
      "Location 1σ",
      `pose ${obs.poseSigma.toFixed(1)} m + sensor ${obs.independentSigma.toFixed(1)} m`,
    ],
    ["Class hypothesis", `${obs.classHypothesis}`],
    ["Class confidence", fmtPct(obs.classConfidence)],
    ["Quality", obs.quality.join(", ")],
    ["Calibration", `${obs.calibrationId} · ${obs.calibrationValid ? "valid" : "expired"}`],
    ["Stage", obs.processingStage],
    ["Lineage", obs.lineage],
    ["Fusion", obs.usableForFusion ? "eligible" : "withheld"],
  ];
  return (
    <div className="flex flex-col gap-3">
      <button type="button" onClick={onBack} className="self-start text-sm text-nx-primary">
        Back to features
      </button>
      <div>
        <div className="text-xs uppercase tracking-wide text-nx-muted">Observation envelope</div>
        <h2 className="text-lg font-medium text-nx-fg">{obs.sensorId}</h2>
      </div>
      {obs.quarantineReason ? (
        <p className="rounded-md border border-nx-primary/40 bg-nx-primary/10 px-3 py-2 text-sm leading-snug text-nx-fg">
          {obs.quarantineReason}
        </p>
      ) : null}
      <dl className="divide-y divide-nx-line border-y border-nx-line">
        {rows.map(([key, value]) => (
          <div key={key} className="grid grid-cols-[7.5rem_1fr] gap-2 py-1.5">
            <dt className="text-xs text-nx-muted">{key}</dt>
            <dd className="font-mono text-xs leading-snug text-nx-fg">{value}</dd>
          </div>
        ))}
      </dl>
      <p className="text-xs leading-relaxed text-nx-muted">
        Location uncertainty and class confidence are different fields. A strong class guess does
        not shrink the ellipse.
      </p>
    </div>
  );
}

function FeatureCard({ track }: { track: Track }) {
  const frame = useFrame();
  const audit = useNexus((s) => s.audit);
  const withheld = useNexus((s) => s.withheld);
  const logReview = useNexus((s) => s.logReview);
  const selectObs = useNexus((s) => s.selectObs);
  const [rationale, setRationale] = useState(
    "Looks consistent. Hold for a field check before publishing.",
  );
  const held = Boolean(withheld[track.id]);
  const top = track.hypotheses[0];
  const weightSum = track.hypotheses.reduce((sum, h) => sum + h.weight, 0) || 1;
  const age = Math.max(0, frame.t - track.lastSupport);
  const related = frame.observations.filter((obs) =>
    track.contributors.some((c) => c.obsId === obs.id),
  );

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <Pill tone={toneFor(track.state, track.conflict)}>
          {held ? "Withheld" : stateLabel(track.state)}
        </Pill>
        <span className="font-mono text-xs text-nx-muted">{track.id}</span>
      </div>
      <div>
        <h2 className="text-lg font-medium leading-tight text-nx-fg">
          {top?.label ?? "Unclassified return"}
        </h2>
        <p className="mt-1 text-sm text-nx-muted">
          Born {fmtTime(track.born)} · last support {fmtTime(track.lastSupport)} · age{" "}
          {age.toFixed(0)} s
        </p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Stat
          label="Location"
          value={`±${Math.round(radius95(track.pxx, track.pxy, track.pyy))} m`}
          note="95% covariance-intersection ellipse. Not a class score."
        />
        <Stat
          label="Class"
          value={top ? fmtPct(top.weight / weightSum) : "—"}
          note="Hypothesis weight only. Does not move the coordinate."
        />
      </div>
      {track.conflict && track.conflictNote ? (
        <p className="rounded-md border border-nx-primary/40 bg-nx-primary/10 px-3 py-2 text-sm leading-snug text-nx-fg">
          {track.conflictNote}
        </p>
      ) : null}
      {track.withheldNearby > 0 ? (
        <p className="text-sm leading-snug text-nx-muted">
          {track.withheldNearby} nearby return{track.withheldNearby === 1 ? "" : "s"} failed the
          time, calibration, or coherence gate and {track.withheldNearby === 1 ? "was" : "were"} not
          merged.
        </p>
      ) : null}
      {track.supportCount > 1 ? (
        <p className="font-mono text-xs leading-relaxed text-nx-muted">
          Naive 95% ±{Math.round(radius95(track.npxx, track.npxy, track.npyy))} m treats shared pose
          error as independent. Intersection keeps the pose floor.
        </p>
      ) : null}
      <div>
        <div className="mb-1 text-xs uppercase tracking-wide text-nx-muted">Hypotheses</div>
        <ul className="flex flex-col gap-1.5">
          {track.hypotheses.map((h) => (
            <li key={h.label}>
              <div className="mb-0.5 flex justify-between gap-2 text-sm">
                <span>{h.label}</span>
                <span className="font-mono text-xs text-nx-muted">{h.sensors.join(" ")}</span>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-nx-surface-2">
                <div
                  className="h-full bg-nx-accent"
                  style={{ width: `${Math.max(6, (h.weight / weightSum) * 100)}%` }}
                />
              </div>
            </li>
          ))}
        </ul>
      </div>
      <div>
        <div className="mb-1 text-xs uppercase tracking-wide text-nx-muted">Evidence</div>
        <ul className="flex flex-col">
          {track.contributors
            .slice()
            .reverse()
            .map((c) => (
              <li key={`${c.obsId}-${c.t}`}>
                <button
                  type="button"
                  className="flex min-h-11 w-full items-center justify-between gap-2 border-b border-nx-line text-left text-sm"
                  onClick={() => selectObs(c.obsId)}
                >
                  <span className="font-mono text-xs">{c.sensorId}</span>
                  <span className="text-nx-muted">{fmtTime(c.t)}</span>
                </button>
              </li>
            ))}
        </ul>
        {related.length === 0 ? (
          <p className="mt-1 text-xs text-nx-muted">
            Source returns have scrolled out of the live window. Lineage ids remain.
          </p>
        ) : null}
      </div>
      <div className="rounded-md border border-nx-line bg-nx-bg p-3">
        <div className="text-xs uppercase tracking-wide text-nx-muted">Operator review</div>
        <p className="mt-1 font-mono text-xs text-nx-muted">
          {BUILD} · {PROFILE}
        </p>
        <label className="mt-2 block text-sm" htmlFor="rationale">
          Rationale
          <textarea
            id="rationale"
            value={rationale}
            onChange={(event) => setRationale(event.target.value)}
            rows={3}
            className="mt-1 w-full resize-y rounded-md border border-nx-line bg-nx-surface px-2 py-2 text-sm text-nx-fg"
          />
        </label>
        <div className="mt-2 flex flex-wrap gap-2">
          <button
            type="button"
            className="min-h-11 rounded-md bg-nx-primary px-3 text-sm font-medium text-nx-primary-fg"
            onClick={() => logReview(track.id, rationale, "review")}
          >
            Log review
          </button>
          {held ? (
            <button
              type="button"
              className="min-h-11 rounded-md border border-nx-line px-3 text-sm"
              onClick={() => logReview(track.id, rationale, "restore")}
            >
              Restore to product
            </button>
          ) : (
            <button
              type="button"
              className="min-h-11 rounded-md border border-nx-line px-3 text-sm"
              onClick={() => logReview(track.id, rationale, "withhold")}
            >
              Withhold from product
            </button>
          )}
        </div>
      </div>
      {audit.filter((entry) => entry.trackId === track.id).length > 0 ? (
        <ul className="flex flex-col gap-2">
          {audit
            .filter((entry) => entry.trackId === track.id)
            .map((entry) => (
              <li key={entry.id} className="text-xs leading-relaxed text-nx-muted">
                <span className="font-mono text-nx-fg">
                  {entry.id} · {fmtTime(entry.t)} · {entry.action}
                </span>
                <br />
                {entry.rationale}
              </li>
            ))}
        </ul>
      ) : null}
    </div>
  );
}

export function Dossier() {
  const frame = useFrame();
  const selectedTrackId = useNexus((s) => s.selectedTrackId);
  const selectedObsId = useNexus((s) => s.selectedObsId);
  const withheld = useNexus((s) => s.withheld);
  const selectTrack = useNexus((s) => s.selectTrack);
  const selectObs = useNexus((s) => s.selectObs);
  const obs = frame.observations.find((item) => item.id === selectedObsId);
  const track = frame.tracks.find((item) => item.id === selectedTrackId);

  const ranked = [...frame.tracks].sort((a, b) => {
    const rank = (state: Track["state"]) =>
      state === "confirmed" ? 0 : state === "degraded" ? 1 : state === "tentative" ? 2 : 3;
    return rank(a.state) - rank(b.state) || b.supportCount - a.supportCount;
  });

  return (
    <aside className="flex h-44 shrink-0 flex-col gap-4 overflow-y-auto border-t border-nx-line bg-nx-surface px-4 py-3 lg:h-auto lg:min-h-0 lg:w-80 lg:shrink-0 lg:border-t-0 lg:border-l lg:py-4">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="text-sm font-medium uppercase tracking-wide text-nx-muted">
          Feature dossier
        </h2>
        <span className="font-mono text-xs text-nx-muted">{frame.confirmed} current</span>
      </div>
      {obs ? (
        <Envelope obs={obs} onBack={() => selectObs(null)} />
      ) : track ? (
        <FeatureCard track={track} />
      ) : (
        <p className="text-sm leading-relaxed text-nx-muted">
          Select a feature. Confirmed means two sensor families agreed on geometry. It does not mean
          the class is settled.
        </p>
      )}
      <div>
        <div className="mb-1 text-xs uppercase tracking-wide text-nx-muted">Live features</div>
        <ul className="flex flex-col">
          {ranked.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => selectTrack(item.id)}
                className={`flex min-h-11 w-full items-center justify-between gap-2 border-b border-nx-line text-left ${
                  item.id === selectedTrackId ? "text-nx-fg" : "text-nx-muted"
                }`}
              >
                <span className="truncate text-sm">{item.hypotheses[0]?.label ?? item.id}</span>
                <span className="shrink-0 font-mono text-xs">
                  {withheld[item.id] ? "withheld" : stateLabel(item.state)}
                </span>
              </button>
            </li>
          ))}
          {ranked.length === 0 ? (
            <li className="py-2 text-sm text-nx-muted">No features at this time.</li>
          ) : null}
        </ul>
      </div>
      <div>
        <div className="mb-1 text-xs uppercase tracking-wide text-nx-muted">This frame</div>
        <ul className="flex flex-col">
          {frame.observations
            .filter((item) => item.family !== "nav")
            .slice(0, 8)
            .map((item, index) => (
              <li key={`${item.id}-${index}`}>
                <button
                  type="button"
                  onClick={() => selectObs(item.id)}
                  className="flex min-h-11 w-full items-center justify-between gap-2 border-b border-nx-line text-left"
                >
                  <span className="font-mono text-xs text-nx-fg">
                    {item.sensorId}
                    {item.suppressed ? " dup" : ""}
                  </span>
                  <span className="truncate text-xs text-nx-muted">{item.quality.join(" ")}</span>
                </button>
              </li>
            ))}
        </ul>
      </div>
    </aside>
  );
}
