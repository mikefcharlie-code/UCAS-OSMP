import { fmtPct, fmtTime } from "@/lib/nexus/format";
import { BUILD, PROFILE } from "@/lib/nexus/model";
import { useFrame, useNexus } from "@/lib/nexus/store";
import type { FrameSnapshot } from "@/lib/nexus/types";

function Block({
  kicker,
  title,
  body,
  live,
}: {
  kicker: string;
  title: string;
  body: string;
  live?: string;
}) {
  return (
    <article className="rounded-md border border-nx-line bg-nx-surface px-3 py-3">
      <div className="text-xs uppercase tracking-wide text-nx-muted">{kicker}</div>
      <h3 className="mt-1 text-sm font-medium text-nx-fg">{title}</h3>
      <p className="mt-1 text-sm leading-relaxed text-nx-muted">{body}</p>
      {live ? <p className="mt-2 font-mono text-xs text-nx-accent">{live}</p> : null}
    </article>
  );
}

function requirementRows(frame: FrameSnapshot, auditCount: number) {
  const bright = frame.tracks.find((tr) => tr.hypotheses[0]?.label === "bright transient");
  const brightOk = !bright || (bright.state !== "confirmed" && bright.state !== "degraded");
  return [
    {
      id: "SYS-001",
      text: "Each measurement carries source, time, frame, and quality.",
      ok: frame.observations.every((obs) => obs.sensorId && obs.frame && obs.quality.length > 0),
      evidence: `${frame.observations.length} envelopes in this frame`,
    },
    {
      id: "SYS-002",
      text: "Products link back to observations and the build that made them.",
      ok: true,
      evidence: BUILD,
    },
    {
      id: "SYS-003",
      text: "Location uncertainty stays separate from class confidence.",
      ok: true,
      evidence: "Feature card shows meters and a class weight as different fields",
    },
    {
      id: "SYS-004",
      text: "Stale, invalid, and conflicting observations are flagged, not dropped silently.",
      ok: true,
      evidence: `${frame.quarantined} quarantined · ${frame.withheldObs} withheld · ${frame.conflicts} class conflicts`,
    },
    {
      id: "SYS-006",
      text: "A single-sensor guess is not published as a confirmed fact.",
      ok: brightOk,
      evidence: bright ? `Bright transient is ${bright.state}` : "No unsupported transient in view",
    },
    {
      id: "SYS-007",
      text: "Operator corrections are logged with time and rationale.",
      ok: auditCount > 0,
      evidence: auditCount
        ? `${auditCount} audit entries`
        : "Log a review on a feature to record one",
    },
    {
      id: "SYS-009",
      text: "The same profile replays the same associations.",
      ok: true,
      evidence: `${PROFILE} · scrub back and the tracks repeat`,
    },
    {
      id: "SYS-010",
      text: "Latency is reported per stage, not hidden in the product.",
      ok: true,
      evidence: `Fusion latency ${frame.latencyMs} ms at ${fmtTime(frame.t)}`,
    },
  ];
}

export function Pipeline() {
  const frame = useFrame();
  const auditCount = useNexus((s) => s.audit.length);
  const rows = requirementRows(frame, auditCount);
  const families = (family: string) =>
    frame.observations.filter((obs) => obs.family === family && !obs.suppressed).length;

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-6 overflow-y-auto px-4 py-4 lg:px-6">
      <div className="max-w-3xl">
        <h2 className="text-xl font-medium text-nx-fg">How a return becomes a feature</h2>
        <p className="mt-2 text-sm leading-relaxed text-nx-muted">
          IR–SAR Nexus is a civilian observation architecture. Adapters from infrared,
          electro-optical, SAR products, LiDAR, passive RF, and navigation all emit one versioned
          envelope. Fusion registers and associates them, and it is required to keep provenance,
          disagreement, and uncertainty. This bench is the first increment: recorded feature-level
          fusion on a single aircraft. It is not a flight-ready design, and it does not guide or
          engage anything.
        </p>
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        <Block
          kicker="Passive"
          title="IR · EO · multispectral · RF"
          body="Thermal contrast, appearance, a moisture index, and spectrum activity. RF is an activity area, not a precise location."
          live={`${families("lwir") + families("eo") + families("ms") + families("rf")} live returns`}
        />
        <Block
          kicker="Active / geometric"
          title="SAR products · LiDAR"
          body="Georeferenced backscatter and range samples. Raw radar phase is out of scope. Low-coherence cells stay masked."
          live={`${families("sar") + families("lidar")} live returns`}
        />
        <Block
          kicker="Reference"
          title="Navigation · timing"
          body="Pose, clock identity, and uncertainty ride with every envelope. If the clock or GNSS degrades, products degrade with it."
          live={
            frame.pose.gnss
              ? `Pose 1σ ${frame.pose.sigma.toFixed(1)} m`
              : `Holdover 1σ ${frame.pose.sigma.toFixed(1)} m`
          }
        />
      </div>
      <div className="grid gap-3 md:grid-cols-4">
        <Block
          kicker="01"
          title="Register"
          body="Put the return in RBND-LOCAL-A using the pose from its own acquisition time, including lever arm and boresight."
        />
        <Block
          kicker="02"
          title="Associate"
          body="Gate on geometry and on whether the class hypotheses can coexist. A conflict starts a second hypothesis instead of a forced id."
        />
        <Block
          kicker="03"
          title="Uncertainty"
          body="Covariance intersection so a shared navigation error is not counted once per sensor. The dashed ellipse is the overconfident alternative."
        />
        <Block
          kicker="04"
          title="Provenance"
          body="Contributors, calibration id, build, and operator rationale stay attached. Coasting features are marked stale instead of looking fresh."
          live={`${frame.coasting} coasting`}
        />
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        <Block
          kicker="Scene"
          title="Corridor surface"
          body="River, roads, bridge, and levee are the map the returns sit on. Coverage gaps stay empty."
        />
        <Block
          kicker="Features"
          title="Evidence-linked tracks"
          body="A feature needs two families before it is confirmed. Class remains a weighted list."
          live={`${frame.confirmed} confirmed · ${fmtPct(frame.ciCoverage)} CI coverage`}
        />
        <Block
          kicker="Assurance"
          title="Health, freshness, lineage"
          body="Sensor loss, expired calibration, and late SAR products change the quality state in the rail. They do not vanish."
          live={`${frame.duplicates} duplicate suppressions in view`}
        />
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[36rem] border-collapse text-left text-sm">
          <caption className="mb-2 text-left text-xs uppercase tracking-wide text-nx-muted">
            Requirements lit by this replay
          </caption>
          <thead className="text-xs uppercase tracking-wide text-nx-muted">
            <tr className="border-b border-nx-line">
              <th className="py-2 pr-3 font-medium">Id</th>
              <th className="py-2 pr-3 font-medium">Requirement</th>
              <th className="py-2 pr-3 font-medium">Now</th>
              <th className="py-2 font-medium">Evidence</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id} className="border-b border-nx-line align-top">
                <td className="py-2 pr-3 font-mono text-xs text-nx-primary">{row.id}</td>
                <td className="py-2 pr-3 text-nx-fg">{row.text}</td>
                <td
                  className={`py-2 pr-3 font-mono text-xs ${row.ok ? "text-nx-accent" : "text-nx-primary"}`}
                >
                  {row.ok ? "pass" : "open"}
                </td>
                <td className="py-2 text-nx-muted">{row.evidence}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
