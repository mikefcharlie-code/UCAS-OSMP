import { useEffect, useState } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { fmtMeters, fmtPct, fmtTime } from "@/lib/nexus/format";
import { useNexus } from "@/lib/nexus/store";

export function Assurance() {
  const frames = useNexus((s) => s.timeline.frames);
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);

  const data = frames
    .filter((_, index) => index % 4 === 0)
    .map((frame) => ({
      t: Math.round(frame.t),
      error: frame.medianError,
      ci: frame.ciCoverage == null ? null : Math.round(frame.ciCoverage * 100),
      naive: frame.naiveCoverage == null ? null : Math.round(frame.naiveCoverage * 100),
      missed: frame.missed,
    }));

  const latest =
    [...frames].reverse().find((frame) => frame.ciCoverage != null) ?? frames[frames.length - 1]!;

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-6 overflow-y-auto px-4 py-4 lg:px-6">
      <div className="max-w-3xl">
        <h2 className="text-xl font-medium text-nx-fg">
          Assurance against the synthetic reference
        </h2>
        <p className="mt-2 text-sm leading-relaxed text-nx-muted">
          Scores compare fused features with the known T3 scene. They are a bench result for this
          replay, not a field accuracy claim. Turn on GNSS loss and watch the dashed naive ellipse
          cover fewer reference points than covariance intersection, even when the pictured ellipse
          looks tighter.
        </p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Metric
          label="Median horizontal error"
          value={fmtMeters(latest.medianError)}
          note="Confirmed features vs reference"
        />
        <Metric
          label="CI 95% coverage"
          value={fmtPct(latest.ciCoverage)}
          note="Reference inside the honest ellipse"
        />
        <Metric
          label="Naive 95% coverage"
          value={fmtPct(latest.naiveCoverage)}
          note="Same points, independent-pose math"
        />
        <Metric
          label="Missed required features"
          value={String(latest.missed)}
          note={`${latest.falseConfirmed} false confirmed`}
        />
      </div>
      <section className="rounded-md border border-nx-line bg-nx-surface p-3">
        <h3 className="text-sm font-medium text-nx-fg">95% ellipse coverage</h3>
        <p className="mt-1 text-xs text-nx-muted">
          Share of matched features whose reference point sits inside the ellipse.
        </p>
        <div className="mt-3 h-56">
          {ready ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid stroke="var(--color-nx-line)" strokeDasharray="3 3" />
                <XAxis
                  dataKey="t"
                  stroke="var(--color-nx-muted)"
                  tick={{ fill: "var(--color-nx-muted)", fontSize: 11 }}
                />
                <YAxis
                  domain={[0, 100]}
                  stroke="var(--color-nx-muted)"
                  tick={{ fill: "var(--color-nx-muted)", fontSize: 11 }}
                  unit="%"
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-nx-surface)",
                    border: "1px solid var(--color-nx-line)",
                    borderRadius: 8,
                    color: "var(--color-nx-fg)",
                  }}
                  labelFormatter={(label) => fmtTime(Number(label))}
                />
                <Line
                  type="monotone"
                  dataKey="ci"
                  name="Intersection"
                  stroke="var(--color-nx-accent)"
                  dot={false}
                  strokeWidth={2}
                  connectNulls={false}
                />
                <Line
                  type="monotone"
                  dataKey="naive"
                  name="Naive"
                  stroke="var(--color-nx-primary)"
                  dot={false}
                  strokeWidth={2}
                  connectNulls={false}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full" />
          )}
        </div>
      </section>
      <section className="rounded-md border border-nx-line bg-nx-surface p-3">
        <h3 className="text-sm font-medium text-nx-fg">Median location error</h3>
        <p className="mt-1 text-xs text-nx-muted">
          Meters from the synthetic reference. Blank gaps are frames with nothing confirmed yet.
        </p>
        <div className="mt-3 h-56">
          {ready ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid stroke="var(--color-nx-line)" strokeDasharray="3 3" />
                <XAxis
                  dataKey="t"
                  stroke="var(--color-nx-muted)"
                  tick={{ fill: "var(--color-nx-muted)", fontSize: 11 }}
                />
                <YAxis
                  stroke="var(--color-nx-muted)"
                  tick={{ fill: "var(--color-nx-muted)", fontSize: 11 }}
                  unit="m"
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-nx-surface)",
                    border: "1px solid var(--color-nx-line)",
                    borderRadius: 8,
                    color: "var(--color-nx-fg)",
                  }}
                  labelFormatter={(label) => fmtTime(Number(label))}
                />
                <Line
                  type="monotone"
                  dataKey="error"
                  name="Median error"
                  stroke="var(--color-nx-fg)"
                  dot={false}
                  strokeWidth={2}
                  connectNulls={false}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full" />
          )}
        </div>
      </section>
    </div>
  );
}

function Metric({ label, value, note }: { label: string; value: string; note: string }) {
  return (
    <div className="rounded-md border border-nx-line bg-nx-surface px-3 py-3">
      <div className="text-xs uppercase tracking-wide text-nx-muted">{label}</div>
      <div className="mt-1 font-mono text-2xl text-nx-fg tabular-nums">{value}</div>
      <div className="mt-1 text-xs text-nx-muted">{note}</div>
    </div>
  );
}
