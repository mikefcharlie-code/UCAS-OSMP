import { useEffect } from "react";
import { Link } from "@tanstack/react-router";
import {
  Activity,
  AudioLines,
  Box,
  Clock,
  Crosshair,
  Droplets,
  Eye,
  Pause,
  Play,
  Radar,
  ShieldAlert,
  Thermometer,
} from "lucide-react";
import { Assurance } from "@/components/nexus/assurance";
import { Dossier } from "@/components/nexus/dossier";
import { Pipeline } from "@/components/nexus/pipeline";
import { SceneCanvas } from "@/components/nexus/scene-canvas";
import { fmtMeters, fmtPct, fmtTime } from "@/lib/nexus/format";
import { frameIndex } from "@/lib/nexus/fusion";
import { DURATION, PRESETS, faultsActive } from "@/lib/nexus/model";
import { useFrame, useNexus } from "@/lib/nexus/store";
import type { Layers } from "@/lib/nexus/store";
import type { SensorId } from "@/lib/nexus/types";

const LAYER_TOGGLES: { key: keyof Layers; label: string }[] = [
  { key: "lwir", label: "IR" },
  { key: "eo", label: "EO" },
  { key: "sar", label: "SAR" },
  { key: "lidar", label: "LiDAR" },
  { key: "ms", label: "MS" },
  { key: "rf", label: "RF" },
  { key: "fused", label: "Fused" },
  { key: "naive", label: "Naive" },
  { key: "truth", label: "Reference" },
  { key: "footprint", label: "Footprint" },
];

const SENSOR_ICON: Record<SensorId, typeof Eye> = {
  "LWIR-A": Thermometer,
  "LWIR-B": Thermometer,
  EO: Eye,
  SAR: Radar,
  LIDAR: Box,
  MS: Droplets,
  RF: AudioLines,
  NAV: Crosshair,
};

export function Console() {
  const frame = useFrame();
  const faults = useNexus((s) => s.faults);
  const layers = useNexus((s) => s.layers);
  const t = useNexus((s) => s.t);
  const playing = useNexus((s) => s.playing);
  const speed = useNexus((s) => s.speed);
  const view = useNexus((s) => s.view);
  const setPlaying = useNexus((s) => s.setPlaying);
  const setSpeed = useNexus((s) => s.setSpeed);
  const setT = useNexus((s) => s.setT);
  const setView = useNexus((s) => s.setView);
  const setFaults = useNexus((s) => s.setFaults);
  const patchFaults = useNexus((s) => s.patchFaults);
  const toggleLayer = useNexus((s) => s.toggleLayer);

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let acc = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      acc += dt;
      if (acc >= 0.1) {
        const step = acc;
        acc = 0;
        const state = useNexus.getState();
        if (state.playing) {
          let next = state.t + step * state.speed;
          if (next > DURATION) next = 0;
          state.setT(next);
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (event.code === "Space") {
        event.preventDefault();
        const state = useNexus.getState();
        state.setPlaying(!state.playing);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    const state = useNexus.getState();
    if (state.selectedTrackId) return;
    const snapshot = state.timeline.frames[frameIndex(state.t, state.timeline.frames.length)];
    if (!snapshot) return;
    const best = [...snapshot.tracks].sort((a, b) => b.supportCount - a.supportCount)[0];
    if (best) state.selectTrack(best.id);
  }, []);

  const degraded = faultsActive(faults);
  const heading = ((frame.pose.heading * 180) / Math.PI + 360) % 360;

  return (
    <div
      className="flex h-dvh flex-col overflow-hidden bg-nx-bg text-nx-fg"
      style={{ backgroundImage: "none" }}
    >
      <header className="border-b border-nx-line bg-nx-surface">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3">
          <div className="flex items-center gap-3">
            <span className="flex size-9 items-center justify-center rounded-md border border-nx-primary/50 text-nx-primary">
              <Crosshair className="size-5" aria-hidden="true" />
            </span>
            <div>
              <div className="text-xs uppercase tracking-widest text-nx-muted">
                NEX-SYS-001 · Rev A
              </div>
              <h1 className="text-lg font-medium leading-tight">IR–SAR Nexus</h1>
            </div>
          </div>
          <p className="max-w-xl text-sm leading-snug text-nx-muted">
            Riverbend corridor · flood-response inspection · single aircraft
          </p>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <Link
              to="/"
              className="inline-flex min-h-8 items-center rounded-full border border-nx-line px-2.5 font-mono text-xs text-nx-muted hover:text-nx-fg"
            >
              ← UCAS/OSMP
            </Link>
            <Status tone={degraded ? "primary" : "accent"}>
              {degraded ? "Degraded" : "Nominal"}
            </Status>
            <Status tone="muted">nex.obs.1</Status>
            <Status tone="muted">T3 replay</Status>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3 border-t border-nx-line px-4 py-2">
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-md border border-nx-line"
            onClick={() => setPlaying(!playing)}
            aria-label={playing ? "Pause replay" : "Play replay"}
          >
            {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
          </button>
          <span className="w-20 font-mono text-sm tabular-nums">{fmtTime(t)}</span>
          <input
            className="h-11 min-w-40 flex-1"
            type="range"
            min={0}
            max={DURATION}
            step={0.5}
            value={t}
            aria-label="Mission time"
            onChange={(event) => {
              setPlaying(false);
              setT(Number(event.target.value));
            }}
          />
          <div className="flex gap-1" role="group" aria-label="Replay speed">
            {[1, 4, 8].map((value) => (
              <button
                key={value}
                type="button"
                aria-pressed={speed === value}
                onClick={() => setSpeed(value)}
                className={`min-h-11 rounded-md px-3 font-mono text-xs ${
                  speed === value
                    ? "bg-nx-primary text-nx-primary-fg"
                    : "border border-nx-line text-nx-muted"
                }`}
              >
                {value}×
              </button>
            ))}
          </div>
          <div className="flex gap-1" role="tablist" aria-label="Console sections">
            {(
              [
                ["map", "Map"],
                ["pipeline", "Pipeline"],
                ["assurance", "Assurance"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={view === id}
                onClick={() => setView(id)}
                className={`min-h-11 rounded-md px-3 text-sm ${
                  view === id ? "bg-nx-surface-2 text-nx-fg" : "text-nx-muted"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      </header>

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row lg:overflow-hidden">
        <nav
          className="flex gap-2 overflow-x-auto border-b border-nx-line px-3 py-2 lg:hidden"
          aria-label="Fault presets"
        >
          {PRESETS.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => setFaults(preset.faults)}
              className="min-h-11 shrink-0 rounded-md border border-nx-line px-3 text-sm"
            >
              {preset.label}
            </button>
          ))}
        </nav>

        {view === "map" ? (
          <aside className="hidden w-72 shrink-0 flex-col gap-4 overflow-y-auto border-r border-nx-line bg-nx-surface px-3 py-3 lg:flex">
            <Rail />
          </aside>
        ) : null}

        <main className="flex min-h-0 min-w-0 flex-1 flex-col lg:overflow-hidden">
          {view === "map" ? (
            <>
              <div className="relative min-h-48 flex-1">
                <div className="absolute inset-0">
                  <SceneCanvas />
                </div>
                <div className="pointer-events-none absolute top-3 left-3 max-w-xs rounded-md border border-nx-line bg-nx-bg/95 px-3 py-2">
                  <div className="font-mono text-xs text-nx-muted">
                    NEX-01 · {Math.round(frame.pose.alt)} m AGL
                  </div>
                  <div className="mt-1 text-sm text-nx-fg">
                    {Math.round(heading)}° · {frame.pose.speed.toFixed(0)} m/s · pose 1σ{" "}
                    {frame.pose.sigma.toFixed(1)} m
                  </div>
                  {frame.ciCoverage != null &&
                  frame.naiveCoverage != null &&
                  frame.naiveCoverage + 0.12 < frame.ciCoverage ? (
                    <p className="mt-1 text-xs leading-snug text-nx-primary">
                      Naive coverage {fmtPct(frame.naiveCoverage)} vs intersection{" "}
                      {fmtPct(frame.ciCoverage)}. The tight ellipse is overconfident.
                    </p>
                  ) : (
                    <p className="mt-1 text-xs leading-snug text-nx-muted">
                      Median error {fmtMeters(frame.medianError)} · CI coverage{" "}
                      {fmtPct(frame.ciCoverage)}
                    </p>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-px border-t border-nx-line bg-nx-line sm:grid-cols-4">
                <Score label="Latency" value={`${frame.latencyMs} ms`} icon={Clock} />
                <Score label="Confirmed" value={String(frame.confirmed)} icon={Activity} />
                <Score
                  label="Withheld"
                  value={String(frame.withheldObs + frame.quarantined)}
                  icon={ShieldAlert}
                />
                <Score label="Missed" value={`${frame.missed}/${frame.required}`} icon={Activity} />
              </div>
              <div className="max-h-36 overflow-y-auto border-t border-nx-line px-3 py-2 lg:hidden">
                <Rail />
              </div>
            </>
          ) : null}
          {view === "pipeline" ? <Pipeline /> : null}
          {view === "assurance" ? <Assurance /> : null}
        </main>

        {view === "map" ? <Dossier /> : null}
      </div>
      <footer className="border-t border-nx-line px-4 py-2 text-xs leading-relaxed text-nx-muted">
        Conceptual baseline for civilian mapping and disaster response. Synthetic scene, not a
        certified performance claim. No weapon guidance, autonomous engagement, or fire-control.
      </footer>
    </div>
  );
}

function Rail() {
  const faults = useNexus((s) => s.faults);
  const layers = useNexus((s) => s.layers);
  const frame = useFrame();
  const setFaults = useNexus((s) => s.setFaults);
  const patchFaults = useNexus((s) => s.patchFaults);
  const toggleLayer = useNexus((s) => s.toggleLayer);
  const activePreset = PRESETS.find((preset) => sameFaults(preset.faults, faults));

  return (
    <>
      <section>
        <h2 className="px-1 text-xs uppercase tracking-wide text-nx-muted">Replay preset</h2>
        <div className="mt-2 flex flex-col gap-1">
          {PRESETS.map((preset) => (
            <button
              key={preset.id}
              type="button"
              aria-pressed={activePreset?.id === preset.id}
              onClick={() => setFaults(preset.faults)}
              className={`min-h-11 rounded-md px-3 text-left text-sm ${
                activePreset?.id === preset.id
                  ? "bg-nx-primary/15 text-nx-fg"
                  : "hover:bg-nx-surface-2"
              }`}
            >
              <span className="block">{preset.label}</span>
              <span className="block text-xs leading-snug text-nx-muted">{preset.note}</span>
            </button>
          ))}
        </div>
      </section>
      <section>
        <h2 className="px-1 text-xs uppercase tracking-wide text-nx-muted">Payload health</h2>
        <ul className="mt-2 flex flex-col">
          {frame.sensors.map((sensor) => {
            const Icon = SENSOR_ICON[sensor.id];
            const tone =
              sensor.status === "nominal"
                ? "text-nx-accent"
                : sensor.status === "offline"
                  ? "text-nx-danger"
                  : "text-nx-primary";
            return (
              <li
                key={sensor.id}
                className="flex min-h-11 items-start gap-2 border-b border-nx-line py-2"
              >
                <Icon className={`mt-0.5 size-4 shrink-0 ${tone}`} aria-hidden="true" />
                <div className="min-w-0">
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="font-mono text-xs text-nx-fg">{sensor.id}</span>
                    <span className={`text-xs ${tone}`}>{sensor.status}</span>
                  </div>
                  <p className="text-xs leading-snug text-nx-muted">{sensor.detail}</p>
                </div>
              </li>
            );
          })}
        </ul>
      </section>
      <section>
        <h2 className="px-1 text-xs uppercase tracking-wide text-nx-muted">Layers</h2>
        <div className="mt-2 flex flex-wrap gap-1">
          {LAYER_TOGGLES.map((layer) => (
            <button
              key={layer.key}
              type="button"
              aria-pressed={layers[layer.key]}
              onClick={() => toggleLayer(layer.key)}
              className={`min-h-11 rounded-md px-3 text-sm ${
                layers[layer.key] ? "bg-nx-surface-2 text-nx-fg" : "text-nx-muted"
              }`}
            >
              {layer.label}
            </button>
          ))}
        </div>
      </section>
      <section>
        <h2 className="px-1 text-xs uppercase tracking-wide text-nx-muted">Fault injection</h2>
        <p className="mt-1 px-1 text-xs leading-snug text-nx-muted">
          The clock stays where it is. The sortie is rebuilt with the fault present the whole pass.
        </p>
        <div className="mt-2 flex flex-col gap-1">
          <Toggle
            label="IR-B aperture occluded"
            on={faults.irBOccluded}
            onClick={() => patchFaults({ irBOccluded: !faults.irBOccluded })}
          />
          <Toggle
            label="Substation IR saturated"
            on={faults.irSaturation}
            onClick={() => patchFaults({ irSaturation: !faults.irSaturation })}
          />
          <Toggle
            label="IR calibration expired"
            on={faults.irBoresight}
            onClick={() => patchFaults({ irBoresight: !faults.irBoresight })}
          />
          <Toggle
            label="GNSS lost, pose coasting"
            on={faults.gnssLoss}
            onClick={() => patchFaults({ gnssLoss: !faults.gnssLoss })}
          />
          <Toggle
            label="SAR low-coherence mask"
            on={faults.sarLowCoherence}
            onClick={() => patchFaults({ sarLowCoherence: !faults.sarLowCoherence })}
          />
          <Toggle
            label="SAR product link down"
            on={faults.linkLoss}
            onClick={() => patchFaults({ linkLoss: !faults.linkLoss })}
          />
          <Toggle
            label="Duplicate SAR delivery"
            on={faults.duplicateInject}
            onClick={() => patchFaults({ duplicateInject: !faults.duplicateInject })}
          />
          <label className="px-1 pt-2 text-sm" htmlFor="clock-offset">
            IR clock offset
            <span className="ml-2 font-mono text-xs text-nx-muted">{faults.clockOffsetMs} ms</span>
            <input
              id="clock-offset"
              className="mt-2 h-11 w-full"
              type="range"
              min={0}
              max={900}
              step={50}
              value={faults.clockOffsetMs}
              onChange={(event) => patchFaults({ clockOffsetMs: Number(event.target.value) })}
            />
          </label>
        </div>
      </section>
    </>
  );
}

function Toggle({ label, on, onClick }: { label: string; on: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className="flex min-h-11 items-center justify-between gap-3 rounded-md px-3 text-left text-sm"
    >
      <span>{label}</span>
      <span className={`font-mono text-xs ${on ? "text-nx-primary" : "text-nx-muted"}`}>
        {on ? "on" : "off"}
      </span>
    </button>
  );
}

function Status({ children, tone }: { children: string; tone: "accent" | "primary" | "muted" }) {
  const tones = {
    accent: "border-nx-accent/40 text-nx-accent",
    primary: "border-nx-primary/50 text-nx-primary",
    muted: "border-nx-line text-nx-muted",
  };
  return (
    <span
      className={`inline-flex min-h-8 items-center rounded-full border px-2.5 text-xs font-medium ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

function Score({ label, value, icon: Icon }: { label: string; value: string; icon: typeof Clock }) {
  return (
    <div className="flex items-center gap-2 bg-nx-surface px-3 py-2">
      <Icon className="size-4 text-nx-muted" aria-hidden="true" />
      <div>
        <div className="text-xs text-nx-muted">{label}</div>
        <div className="font-mono text-sm tabular-nums">{value}</div>
      </div>
    </div>
  );
}

function sameFaults(
  a: (typeof PRESETS)[number]["faults"],
  b: (typeof PRESETS)[number]["faults"],
): boolean {
  return (
    a.irBOccluded === b.irBOccluded &&
    a.irSaturation === b.irSaturation &&
    a.irBoresight === b.irBoresight &&
    a.clockOffsetMs === b.clockOffsetMs &&
    a.gnssLoss === b.gnssLoss &&
    a.sarLowCoherence === b.sarLowCoherence &&
    a.linkLoss === b.linkLoss &&
    a.duplicateInject === b.duplicateInject
  );
}
