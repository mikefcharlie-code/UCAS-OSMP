import type { TrackState } from "./types";

export function fmtTime(t: number): string {
  const clamped = Math.max(0, t);
  const m = Math.floor(clamped / 60);
  const s = clamped - m * 60;
  return `${m}:${s.toFixed(1).padStart(4, "0")}`;
}

export function fmtMeters(n: number | null | undefined): string {
  if (n == null || Number.isNaN(n)) return "—";
  return `${n.toFixed(1)} m`;
}

export function fmtPct(n: number | null | undefined): string {
  if (n == null || Number.isNaN(n)) return "—";
  return `${Math.round(n * 100)}%`;
}

export function stateLabel(state: TrackState): string {
  switch (state) {
    case "confirmed":
      return "Confirmed";
    case "degraded":
      return "Degraded";
    case "tentative":
      return "Tentative";
    case "coasting":
      return "Coasting";
    case "dropped":
      return "Dropped";
  }
}

export function sigmaMajor(pxx: number, pxy: number, pyy: number): number {
  const tr = pxx + pyy;
  const det = pxx * pyy - pxy * pxy;
  const disc = Math.sqrt(Math.max(0, (tr * tr) / 4 - det));
  return Math.sqrt(Math.max(0.01, tr / 2 + disc));
}

export function radius95(pxx: number, pxy: number, pyy: number): number {
  return sigmaMajor(pxx, pxy, pyy) * Math.sqrt(5.991);
}
