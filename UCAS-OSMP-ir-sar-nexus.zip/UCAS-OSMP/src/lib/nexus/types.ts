export type SensorId = "LWIR-A" | "LWIR-B" | "EO" | "SAR" | "LIDAR" | "MS" | "RF" | "NAV";

export type SensorFamily = "lwir" | "eo" | "sar" | "lidar" | "ms" | "rf" | "nav";

export type QualityFlag =
  | "ok"
  | "stale"
  | "saturated"
  | "obscured"
  | "incomplete"
  | "invalid"
  | "cal_expired"
  | "clock_degraded"
  | "time_quarantine"
  | "low_coherence"
  | "pose_degraded"
  | "duplicate";

export type TrackState = "tentative" | "confirmed" | "degraded" | "coasting" | "dropped";

export type ClassLabel =
  | "thermal anomaly"
  | "cool wet surface"
  | "surface disruption"
  | "elevation change"
  | "moisture index"
  | "visual change"
  | "structural edge"
  | "bright transient"
  | "spectrum activity"
  | "navigation fix";

export interface Faults {
  irBOccluded: boolean;
  irSaturation: boolean;
  irBoresight: boolean;
  clockOffsetMs: number;
  gnssLoss: boolean;
  sarLowCoherence: boolean;
  linkLoss: boolean;
  duplicateInject: boolean;
}

export interface Observation {
  id: string;
  schema: "nex.obs.1";
  sensorId: SensorId;
  family: SensorFamily;
  platformId: "NEX-01";
  tAcquire: number;
  tReceive: number;
  tShowUntil: number;
  timeUncertaintyS: number;
  clockId: string;
  frame: "RBND-LOCAL-A";
  x: number;
  y: number;
  pxx: number;
  pyy: number;
  pxy: number;
  poseSigma: number;
  independentSigma: number;
  classHypothesis: ClassLabel;
  classConfidence: number;
  quality: QualityFlag[];
  calibrationId: string;
  calibrationValid: boolean;
  lineage: string;
  seq: number;
  poseRef: string;
  processingStage: "sensor" | "sar_product" | "navigation";
  usableForFusion: boolean;
  suppressed: boolean;
  quarantineReason?: string | undefined;
  truthId?: string | undefined;
}

export interface Hypothesis {
  label: ClassLabel;
  weight: number;
  sensors: SensorFamily[];
}

export interface Contributor {
  sensorId: SensorId;
  obsId: string;
  t: number;
  family: SensorFamily;
}

export interface Track {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  pxx: number;
  pyy: number;
  pxy: number;
  nx: number;
  ny: number;
  npxx: number;
  npyy: number;
  npxy: number;
  hypotheses: Hypothesis[];
  contributors: Contributor[];
  families: SensorFamily[];
  lastSupport: number;
  born: number;
  state: TrackState;
  conflict: boolean;
  conflictNote?: string | undefined;
  poseSigma: number;
  supportCount: number;
  withheldNearby: number;
}

export interface Pose {
  x: number;
  y: number;
  heading: number;
  alt: number;
  speed: number;
  vx: number;
  vy: number;
  sigma: number;
  gnss: boolean;
  clockOk: boolean;
}

export interface SensorHealth {
  id: SensorId;
  family: SensorFamily;
  status: "nominal" | "degraded" | "offline" | "stale";
  detail: string;
  count: number;
}

export interface FrameSnapshot {
  t: number;
  pose: Pose;
  observations: Observation[];
  tracks: Track[];
  quarantined: number;
  duplicates: number;
  withheldObs: number;
  latencyMs: number;
  medianError: number | null;
  naiveMedianError: number | null;
  ciCoverage: number | null;
  naiveCoverage: number | null;
  matched: number;
  missed: number;
  falseConfirmed: number;
  confirmed: number;
  coasting: number;
  conflicts: number;
  required: number;
  sensors: SensorHealth[];
  notices: string[];
}

export interface Timeline {
  frames: FrameSnapshot[];
  profile: string;
  schema: "nex.obs.1";
  build: string;
}
