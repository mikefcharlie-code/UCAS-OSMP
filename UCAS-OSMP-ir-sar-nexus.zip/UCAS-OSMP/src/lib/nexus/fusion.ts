import {
  BUILD,
  CLOCK_QUARANTINE_MS,
  DETECTORS,
  DT,
  DURATION,
  PROFILE,
  TRUTHS,
  TruthObject,
  bodyRight,
  gauss,
  hashUnit,
  labelsCompatible,
  poseAt,
  poseErrorAt,
  poseSigmaAt,
} from "./model";
import type {
  ClassLabel,
  Contributor,
  Faults,
  FrameSnapshot,
  Observation,
  QualityFlag,
  SensorHealth,
  SensorId,
  Track,
  TrackState,
} from "./types";

const CHI2_95 = 5.991;
const GATE = 9.21;

interface Gauss2 {
  x: number;
  y: number;
  pxx: number;
  pyy: number;
  pxy: number;
}

function infoFuse(a: Gauss2, b: Gauss2, wa: number, wb: number): Gauss2 {
  const da = a.pxx * a.pyy - a.pxy * a.pxy;
  const db = b.pxx * b.pyy - b.pxy * b.pxy;
  if (da < 1e-6 || db < 1e-6) return { ...a };
  const axx = a.pyy / da;
  const axy = -a.pxy / da;
  const ayy = a.pxx / da;
  const bxx = b.pyy / db;
  const bxy = -b.pxy / db;
  const byy = b.pxx / db;
  const ixx = wa * axx + wb * bxx;
  const ixy = wa * axy + wb * bxy;
  const iyy = wa * ayy + wb * byy;
  const det = ixx * iyy - ixy * ixy;
  if (det < 1e-8) return { ...a };
  const pxx = iyy / det;
  const pyy = ixx / det;
  const pxy = -ixy / det;
  const gx = wa * (axx * a.x + axy * a.y) + wb * (bxx * b.x + bxy * b.y);
  const gy = wa * (axy * a.x + ayy * a.y) + wb * (bxy * b.x + byy * b.y);
  return {
    x: pxx * gx + pxy * gy,
    y: pxy * gx + pyy * gy,
    pxx,
    pyy,
    pxy,
  };
}

function mahal(dx: number, dy: number, pxx: number, pxy: number, pyy: number): number {
  const det = pxx * pyy - pxy * pxy;
  if (det < 1e-6) return Infinity;
  const ixx = pyy / det;
  const ixy = -pxy / det;
  const iyy = pxx / det;
  return dx * (ixx * dx + ixy * dy) + dy * (ixy * dx + iyy * dy);
}

function cloneTrack(tr: Track): Track {
  return {
    ...tr,
    hypotheses: tr.hypotheses.map((h) => ({ ...h, sensors: [...h.sensors] })),
    contributors: tr.contributors.map((c) => ({ ...c })),
    families: [...tr.families],
  };
}

function compatibleWithTrack(tr: Track, label: ClassLabel, confidence: number): boolean {
  const top = tr.hypotheses[0];
  if (!top) return true;
  if (confidence < 0.4 || top.weight < 0.35) return true;
  return labelsCompatible(top.label, label);
}

function pushEvidence(
  tr: Track,
  label: ClassLabel,
  confidence: number,
  family: Track["families"][number],
) {
  let hyp = tr.hypotheses.find((h) => h.label === label);
  if (!hyp) {
    hyp = { label, weight: 0, sensors: [] };
    tr.hypotheses.push(hyp);
  }
  if (!hyp.sensors.includes(family)) hyp.sensors.push(family);
  hyp.weight = 1 - (1 - hyp.weight) * (1 - Math.min(0.95, confidence) * 0.62);
  tr.hypotheses.sort((a, b) => b.weight - a.weight);
  const top = tr.hypotheses[0];
  const second = tr.hypotheses[1];
  tr.conflict = Boolean(
    second && second.weight > 0.38 && top && !labelsCompatible(top.label, second.label),
  );
  tr.conflictNote = tr.conflict
    ? `${top?.label} and ${second?.label} both have support. They are kept as separate hypotheses.`
    : undefined;
}

function lifecycle(tr: Track, t: number): TrackState {
  const age = t - tr.lastSupport;
  if (age > 100) return "dropped";
  if (age > 8) return "coasting";
  const recent = new Set(
    tr.contributors
      .filter((c) => t - c.t <= 14 && c.family !== "rf" && c.family !== "nav")
      .map((c) => c.family),
  );
  if (recent.size >= 2 && tr.conflict) return "degraded";
  if (recent.size >= 2 && tr.poseSigma > 12) return "degraded";
  if (recent.size >= 2) return "confirmed";
  return "tentative";
}

function predict(tracks: Track[], dt: number) {
  for (const tr of tracks) {
    tr.x += tr.vx * dt;
    tr.y += tr.vy * dt;
    tr.nx += tr.vx * dt;
    tr.ny += tr.vy * dt;
    const q = dt * (0.7 + tr.poseSigma * 0.12 + (Math.abs(tr.vx) + Math.abs(tr.vy)) * 0.25);
    tr.pxx += q;
    tr.pyy += q;
    tr.npxx += q;
    tr.npyy += q;
  }
}

function associate(tracks: Track[], obs: Observation, t: number, nextId: () => string) {
  let best: Track | null = null;
  let bestD = GATE;
  for (const tr of tracks) {
    if (!compatibleWithTrack(tr, obs.classHypothesis, obs.classConfidence)) continue;
    const dx = obs.x - tr.x;
    const dy = obs.y - tr.y;
    const d = mahal(dx, dy, tr.pxx + obs.pxx, tr.pxy + obs.pxy, tr.pyy + obs.pyy);
    if (d < bestD) {
      bestD = d;
      best = tr;
    }
  }

  if (!best) {
    const born: Track = {
      id: nextId(),
      x: obs.x,
      y: obs.y,
      vx: 0,
      vy: 0,
      pxx: obs.pxx,
      pyy: obs.pyy,
      pxy: obs.pxy,
      nx: obs.x,
      ny: obs.y,
      npxx: obs.pxx,
      npyy: obs.pyy,
      npxy: obs.pxy,
      hypotheses: [],
      contributors: [],
      families: [],
      lastSupport: t,
      born: t,
      state: "tentative",
      conflict: false,
      poseSigma: obs.poseSigma,
      supportCount: 0,
      withheldNearby: 0,
    };
    pushEvidence(born, obs.classHypothesis, obs.classConfidence, obs.family);
    remember(born, obs, t);
    tracks.push(born);
    return;
  }

  const dtv = Math.max(0.5, t - best.lastSupport);
  best.vx = clamp(best.vx + (0.32 * (obs.x - best.x)) / dtv, -3, 3);
  best.vy = clamp(best.vy + (0.32 * (obs.y - best.y)) / dtv, -3, 3);
  const fused = infoFuse(best, obs, 0.5, 0.5);
  best.x = fused.x;
  best.y = fused.y;
  best.pxx = fused.pxx;
  best.pyy = fused.pyy;
  best.pxy = fused.pxy;
  const naive = infoFuse(naiveOf(best), obs, 1, 1);
  best.nx = naive.x;
  best.ny = naive.y;
  best.npxx = naive.pxx;
  best.npyy = naive.pyy;
  best.npxy = naive.pxy;
  best.poseSigma = Math.max(best.poseSigma * 0.85, obs.poseSigma);
  pushEvidence(best, obs.classHypothesis, obs.classConfidence, obs.family);
  remember(best, obs, t);
}

function remember(tr: Track, obs: Observation, t: number) {
  const contributor: Contributor = {
    sensorId: obs.sensorId,
    obsId: obs.id,
    t,
    family: obs.family,
  };
  tr.contributors.push(contributor);
  if (tr.contributors.length > 16) tr.contributors.splice(0, tr.contributors.length - 16);
  if (!tr.families.includes(obs.family)) tr.families.push(obs.family);
  tr.lastSupport = t;
  tr.supportCount += 1;
}

function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, v));
}

function naiveOf(tr: Track): Gauss2 {
  return { x: tr.nx, y: tr.ny, pxx: tr.npxx, pyy: tr.npyy, pxy: tr.npxy };
}

function mergeTracks(tracks: Track[]) {
  let changed = true;
  while (changed) {
    changed = false;
    for (let i = 0; i < tracks.length && !changed; i++) {
      for (let j = i + 1; j < tracks.length; j++) {
        const a = tracks[i]!;
        const b = tracks[j]!;
        const la = a.hypotheses[0]?.label;
        const lb = b.hypotheses[0]?.label;
        if (!la || !lb || !labelsCompatible(la, lb)) continue;
        if ((la === "spectrum activity" || lb === "spectrum activity") && la !== lb) continue;
        if ((la === "bright transient" || lb === "bright transient") && la !== lb) continue;
        const dx = a.x - b.x;
        const dy = a.y - b.y;
        const cap = Math.max(46, Math.max(a.poseSigma, b.poseSigma) * 2);
        if (Math.hypot(dx, dy) > cap) continue;
        if (mahal(dx, dy, a.pxx + b.pxx, a.pxy + b.pxy, a.pyy + b.pyy) > GATE) continue;
        const keep = a.born <= b.born ? a : b;
        const drop = keep === a ? b : a;
        const fused = infoFuse(keep, drop, 0.5, 0.5);
        keep.x = fused.x;
        keep.y = fused.y;
        keep.pxx = fused.pxx;
        keep.pyy = fused.pyy;
        keep.pxy = fused.pxy;
        const naive = infoFuse(naiveOf(keep), naiveOf(drop), 1, 1);
        keep.nx = naive.x;
        keep.ny = naive.y;
        keep.npxx = naive.pxx;
        keep.npyy = naive.pyy;
        keep.npxy = naive.pxy;
        for (const hyp of drop.hypotheses) {
          const existing = keep.hypotheses.find((item) => item.label === hyp.label);
          if (!existing) keep.hypotheses.push({ ...hyp, sensors: [...hyp.sensors] });
          else {
            existing.weight = Math.max(existing.weight, hyp.weight);
            for (const sensor of hyp.sensors) {
              if (!existing.sensors.includes(sensor)) existing.sensors.push(sensor);
            }
          }
        }
        keep.hypotheses.sort((left, right) => right.weight - left.weight);
        const top = keep.hypotheses[0];
        const second = keep.hypotheses[1];
        if (top && second && second.weight > 0.38 && !labelsCompatible(top.label, second.label)) {
          keep.conflict = true;
          keep.conflictNote = `${top.label} and ${second.label} both have support. They are kept as separate hypotheses.`;
        } else {
          keep.conflict = false;
          keep.conflictNote = undefined;
        }
        for (const family of drop.families) {
          if (!keep.families.includes(family)) keep.families.push(family);
        }
        keep.contributors.push(...drop.contributors);
        keep.contributors.sort((left, right) => left.t - right.t);
        if (keep.contributors.length > 16)
          keep.contributors.splice(0, keep.contributors.length - 16);
        keep.supportCount += drop.supportCount;
        keep.lastSupport = Math.max(keep.lastSupport, drop.lastSupport);
        keep.born = Math.min(keep.born, drop.born);
        keep.vx = (keep.vx + drop.vx) / 2;
        keep.vy = (keep.vy + drop.vy) / 2;
        keep.poseSigma = Math.max(keep.poseSigma, drop.poseSigma);
        tracks.splice(tracks.indexOf(drop), 1);
        changed = true;
        break;
      }
    }
  }
}

function moduleCenter(sensorId: SensorId, x: number, y: number, heading: number) {
  const right = bodyRight(heading);
  const sign = sensorId === "LWIR-A" ? 1 : sensorId === "LWIR-B" ? -1 : 0;
  return { x: x + right.x * 22 * sign, y: y + right.y * 22 * sign };
}

function makeObservation(
  partial: Omit<Observation, "schema" | "platformId" | "frame" | "suppressed"> & {
    suppressed?: boolean | undefined;
  },
): Observation {
  return {
    schema: "nex.obs.1",
    platformId: "NEX-01",
    frame: "RBND-LOCAL-A",
    ...partial,
    suppressed: partial.suppressed ?? false,
  };
}

function qualityOf(flags: QualityFlag[]): QualityFlag[] {
  const unique = [...new Set(flags)];
  if (unique.length === 0) return ["ok"];
  if (unique.some((flag) => flag !== "ok")) return unique.filter((flag) => flag !== "ok");
  return ["ok"];
}

function detectOne(
  spec: (typeof DETECTORS)[number],
  truth: TruthObject,
  t: number,
  faults: Faults,
  seq: number,
): Observation | null {
  const signature = truth.signatures[spec.family] ?? 0;
  const read = truth.reads[spec.family];
  if (!read || signature < 0.12) return null;
  if (spec.id === "LWIR-B" && faults.irBOccluded) return null;

  const platform = poseAt(t);
  const center = moduleCenter(spec.id, platform.x, platform.y, platform.heading);
  const tx = truth.x(t);
  const ty = truth.y(t);
  const dist = Math.hypot(tx - center.x, ty - center.y);
  if (dist > spec.range) return null;

  const edge = 1 - dist / spec.range;
  const p = signature * (0.42 + 0.58 * edge);
  const bucket = Math.floor(t / 4);
  if (hashUnit(`${spec.id}|${truth.id}|${bucket}`) > p) return null;

  const offsetS = spec.family === "lwir" ? faults.clockOffsetMs / 1000 : 0;
  const tReported = t + offsetS;
  const poseErr = poseErrorAt(tReported, faults);
  const bias = spec.family === "lwir" && faults.irBoresight ? { x: 26, y: -24 } : { x: 0, y: 0 };
  const noiseX = gauss(`n:${spec.id}:${truth.id}:${bucket}:x`) * spec.sigma;
  const noiseY = gauss(`n:${spec.id}:${truth.id}:${bucket}:y`) * spec.sigma;
  const flags: QualityFlag[] = [];
  let usable = true;
  let reason: string | undefined;
  let classConfidence = read.confidence;
  let sigma = spec.sigma;
  let calibrationValid = true;
  let calibrationId = spec.calibrationId;
  let latency = spec.latency;

  if (spec.family === "lwir" && faults.irBoresight) {
    flags.push("cal_expired");
    calibrationValid = false;
    calibrationId = "CAL-IR-2025-002";
    usable = false;
    reason = "Calibration validity expired. IR return withheld from fusion.";
  }
  if (spec.family === "lwir" && faults.clockOffsetMs > 0) {
    if (faults.clockOffsetMs > CLOCK_QUARANTINE_MS) {
      flags.push("time_quarantine");
      usable = false;
      reason = `Clock offset ${faults.clockOffsetMs} ms exceeds the ${CLOCK_QUARANTINE_MS} ms alignment budget. Quarantined.`;
    } else if (faults.clockOffsetMs > 120) {
      flags.push("clock_degraded");
      sigma += platform.speed * offsetS;
    }
  }
  if (faults.irSaturation && spec.family === "lwir" && truth.id === "substation") {
    flags.push("saturated");
    classConfidence *= 0.22;
    sigma *= 2.4;
  }
  if (faults.sarLowCoherence && spec.family === "sar" && tx < 400) {
    flags.push("low_coherence");
    usable = false;
    reason = "SAR product cell is inside the low-coherence mask. Excluded from geometry.";
  }
  if (faults.linkLoss && spec.family === "sar") {
    flags.push("stale");
    latency = 14;
    usable = false;
    reason = "Link loss. SAR product is older than the freshness budget and is not current.";
  }
  if (faults.gnssLoss) flags.push("pose_degraded");

  const poseVar = poseErr.sigma * poseErr.sigma;
  const indVar = sigma * sigma;
  const tReceive = t + latency;
  return makeObservation({
    id: `O-${spec.id}-${truth.id}-${bucket}`,
    sensorId: spec.id,
    family: spec.family,
    tAcquire: t,
    tReceive,
    tShowUntil: tReceive + 4,
    timeUncertaintyS: spec.family === "lwir" ? Math.max(0.004, offsetS) : 0.004,
    clockId: faults.gnssLoss ? "NEX-CLK-HOLDOVER" : "NEX-CLK-1",
    x: tx + poseErr.ex + platform.vx * offsetS + bias.x + noiseX,
    y: ty + poseErr.ey + platform.vy * offsetS + bias.y + noiseY,
    pxx: poseVar + indVar,
    pyy: poseVar + indVar,
    pxy: 0,
    poseSigma: poseErr.sigma,
    independentSigma: sigma,
    classHypothesis: read.label,
    classConfidence,
    quality: qualityOf(flags),
    calibrationId,
    calibrationValid,
    lineage: `${spec.id} adapter → envelope ${PROFILE}`,
    seq,
    poseRef: `POSE-NEX01-${Math.round(tReported * 2)}`,
    processingStage: spec.stage,
    usableForFusion: usable,
    quarantineReason: reason,
    truthId: truth.id,
  });
}

function navObservation(t: number, faults: Faults, seq: number): Observation {
  const platform = poseAt(t);
  const err = poseErrorAt(t, faults);
  const flags: QualityFlag[] = [];
  if (faults.gnssLoss) flags.push("pose_degraded");
  if (faults.clockOffsetMs > CLOCK_QUARANTINE_MS) flags.push("clock_degraded");
  return makeObservation({
    id: `O-NAV-${Math.round(t * 2)}`,
    sensorId: "NAV",
    family: "nav",
    tAcquire: t,
    tReceive: t + 0.05,
    tShowUntil: t + DT,
    timeUncertaintyS: faults.clockOffsetMs > 0 ? faults.clockOffsetMs / 1000 : 0.002,
    clockId: faults.gnssLoss ? "NEX-CLK-HOLDOVER" : "NEX-CLK-1",
    x: platform.x + err.ex,
    y: platform.y + err.ey,
    pxx: err.sigma * err.sigma,
    pyy: err.sigma * err.sigma,
    pxy: 0,
    poseSigma: err.sigma,
    independentSigma: 0.4,
    classHypothesis: "navigation fix",
    classConfidence: faults.gnssLoss ? 0.34 : 0.93,
    quality: qualityOf(flags),
    calibrationId: "CAL-NAV-2026-011",
    calibrationValid: true,
    lineage: "navigation adapter → envelope",
    seq,
    poseRef: `POSE-NEX01-${Math.round(t * 2)}`,
    processingStage: "navigation",
    usableForFusion: false,
    quarantineReason: faults.gnssLoss
      ? "GNSS lost. Pose is coasting; uncertainty is propagated into every registered product."
      : undefined,
  });
}

function sensorHealth(observations: Observation[], faults: Faults, t: number): SensorHealth[] {
  const rows: SensorHealth[] = DETECTORS.map((spec) => {
    const mine = observations.filter((obs) => obs.sensorId === spec.id && !obs.suppressed);
    let status: SensorHealth["status"] = "nominal";
    let detail = mine.length ? `${mine.length} returns in footprint` : "No target in footprint";
    if (spec.id === "LWIR-B" && faults.irBOccluded) {
      status = "offline";
      detail = "Aperture occluded. Coverage gap is explicit.";
    } else if (spec.family === "sar" && faults.linkLoss) {
      status = "stale";
      detail = "Product link down. Last cells are marked stale.";
    } else if (spec.family === "sar" && faults.sarLowCoherence) {
      status = "degraded";
      detail = "Low-coherence mask active on the west bank.";
    } else if (spec.family === "lwir" && faults.irBoresight) {
      status = "degraded";
      detail = "Boresight calibration expired. Returns withheld.";
    } else if (spec.family === "lwir" && faults.clockOffsetMs > CLOCK_QUARANTINE_MS) {
      status = "degraded";
      detail = "Clock offset quarantined this module.";
    } else if (
      faults.irSaturation &&
      spec.family === "lwir" &&
      mine.some((obs) => obs.quality.includes("saturated"))
    ) {
      status = "degraded";
      detail = "Detector saturation on a hot yard.";
    }
    return { id: spec.id, family: spec.family, status, detail, count: mine.length };
  });
  rows.push({
    id: "NAV",
    family: "nav",
    status: faults.gnssLoss || faults.clockOffsetMs > CLOCK_QUARANTINE_MS ? "degraded" : "nominal",
    detail: faults.gnssLoss
      ? `Holdover. 1σ pose ${poseSigmaAt(t, faults).toFixed(1)} m`
      : `GNSS disciplined. 1σ pose ${poseSigmaAt(t, faults).toFixed(1)} m`,
    count: 1,
  });
  return rows;
}

function score(tracks: Track[], t: number) {
  const used = new Set<string>();
  const matched: { tr: Track; truth: TruthObject; d: number }[] = [];
  const candidates = tracks.filter((tr) => !tr.families.every((family) => family === "rf"));
  for (const tr of candidates) {
    let best: TruthObject | null = null;
    let bestD = 70;
    for (const truth of TRUTHS) {
      if (truth.id === "rf" || used.has(truth.id)) continue;
      const d = Math.hypot(tr.x - truth.x(t), tr.y - truth.y(t));
      if (d < bestD) {
        bestD = d;
        best = truth;
      }
    }
    if (best) {
      used.add(best.id);
      matched.push({ tr, truth: best, d: bestD });
    }
  }
  const confirmedMatches = matched.filter(
    (m) => m.tr.state === "confirmed" || m.tr.state === "degraded",
  );
  const medianOf = (values: number[]) =>
    values.length ? values.sort((a, b) => a - b)[Math.floor((values.length - 1) / 2)]! : null;
  const errors = confirmedMatches.map((m) => m.d);
  const naiveErrors = confirmedMatches.map((m) =>
    Math.hypot(m.tr.nx - m.truth.x(t), m.tr.ny - m.truth.y(t)),
  );
  const covered = (which: "ci" | "naive") => {
    if (!confirmedMatches.length) return null;
    let hit = 0;
    for (const m of confirmedMatches) {
      const dx = m.truth.x(t) - (which === "ci" ? m.tr.x : m.tr.nx);
      const dy = m.truth.y(t) - (which === "ci" ? m.tr.y : m.tr.ny);
      const pxx = which === "ci" ? m.tr.pxx : m.tr.npxx;
      const pyy = which === "ci" ? m.tr.pyy : m.tr.npyy;
      const pxy = which === "ci" ? m.tr.pxy : m.tr.npxy;
      if (mahal(dx, dy, pxx, pxy, pyy) <= CHI2_95) hit += 1;
    }
    return hit / confirmedMatches.length;
  };
  const required = TRUTHS.filter((truth) => truth.required);
  return {
    medianError: medianOf(errors),
    naiveMedianError: medianOf(naiveErrors),
    ciCoverage: covered("ci"),
    naiveCoverage: covered("naive"),
    matched: confirmedMatches.length,
    missed: required.filter((truth) => !used.has(truth.id)).length,
    falseConfirmed: tracks.filter((tr) => {
      if (tr.state !== "confirmed" && tr.state !== "degraded") return false;
      if (tr.families.every((family) => family === "rf")) return false;
      return !matched.some((m) => m.tr.id === tr.id);
    }).length,
    required: required.length,
  };
}

export function buildTimeline(faults: Faults) {
  const frames: FrameSnapshot[] = [];
  const tracks: Track[] = [];
  const live: Observation[] = [];
  const applied = new Set<string>();
  let featureSeq = 1;
  const nextId = () => `F${String(featureSeq++).padStart(3, "0")}`;
  let seq = 1;

  for (let step = 0; step <= Math.round(DURATION / DT); step++) {
    const t = Math.round(step * DT * 1000) / 1000;
    predict(tracks, step === 0 ? 0 : DT);

    for (const spec of DETECTORS) {
      for (const truth of TRUTHS) {
        const obs = detectOne(spec, truth, t, faults, seq);
        if (!obs) continue;
        if (live.some((item) => item.id === obs.id) || applied.has(obs.id)) continue;
        seq += 1;
        live.push(obs);
        if (faults.duplicateInject && spec.id === "SAR") {
          live.push({
            ...obs,
            suppressed: true,
            quality: qualityOf([...obs.quality, "duplicate"]),
          });
        }
      }
    }

    const observations: Observation[] = [];
    const notices: string[] = [];
    for (let i = live.length - 1; i >= 0; i--) {
      if (live[i]!.tShowUntil < t) {
        live.splice(i, 1);
        continue;
      }
      if (live[i]!.tReceive > t + 1e-6) continue;
      observations.push(live[i]!);
    }
    observations.push(navObservation(t, faults, seq));
    seq += 1;

    let duplicates = 0;
    const fusionQueue = observations
      .filter((obs) => obs.family !== "nav")
      .slice()
      .sort((a, b) => a.independentSigma - b.independentSigma);
    for (const obs of fusionQueue) {
      if (obs.suppressed) {
        duplicates += 1;
        if (!applied.has(`dup:${obs.id}`)) {
          applied.add(`dup:${obs.id}`);
          notices.push(`Duplicate ${obs.id} suppressed at ingest.`);
        }
        continue;
      }
      if (applied.has(obs.id)) continue;
      applied.add(obs.id);
      if (!obs.usableForFusion) continue;
      associate(tracks, obs, t, nextId);
    }

    mergeTracks(tracks);
    for (let i = tracks.length - 1; i >= 0; i--) {
      const tr = tracks[i]!;
      tr.state = lifecycle(tr, t);
      tr.withheldNearby = observations.filter(
        (obs) =>
          !obs.suppressed &&
          !obs.usableForFusion &&
          obs.family !== "nav" &&
          Math.hypot(obs.x - tr.x, obs.y - tr.y) < 55,
      ).length;
      if (tr.state === "dropped") tracks.splice(i, 1);
    }

    const platform = poseAt(t);
    const err = poseErrorAt(t, faults);
    const metrics = score(tracks, t);
    const visible = observations.filter((obs) => !obs.suppressed && obs.family !== "nav");
    const quarantined = visible.filter((obs) => obs.quality.includes("time_quarantine")).length;
    const withheldObs = visible.filter(
      (obs) => !obs.usableForFusion && !obs.quality.includes("time_quarantine"),
    ).length;
    const usableTimes = visible.filter((obs) => obs.usableForFusion).map((obs) => t - obs.tAcquire);
    const latencyMs = Math.round(
      ((usableTimes.length ? Math.max(...usableTimes) : 0.2) + 0.12) * 1000,
    );

    frames.push({
      t,
      pose: {
        x: platform.x,
        y: platform.y,
        heading: platform.heading,
        alt: platform.alt,
        speed: platform.speed,
        vx: platform.vx,
        vy: platform.vy,
        sigma: err.sigma,
        gnss: !faults.gnssLoss,
        clockOk: faults.clockOffsetMs <= CLOCK_QUARANTINE_MS,
      },
      observations,
      tracks: tracks.map(cloneTrack),
      quarantined,
      duplicates,
      withheldObs,
      latencyMs,
      ...metrics,
      confirmed: tracks.filter((tr) => tr.state === "confirmed").length,
      coasting: tracks.filter((tr) => tr.state === "coasting").length,
      conflicts: tracks.filter((tr) => tr.conflict).length,
      sensors: sensorHealth(observations, faults, t),
      notices: notices.slice(0, 4),
    });
  }

  return { frames, profile: PROFILE, schema: "nex.obs.1" as const, build: BUILD };
}

export function frameIndex(t: number, length: number): number {
  return Math.max(0, Math.min(length - 1, Math.round(t / DT)));
}

export { CHI2_95, mahal };
