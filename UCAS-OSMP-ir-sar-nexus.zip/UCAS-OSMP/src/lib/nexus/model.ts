import type { ClassLabel, Faults, SensorFamily, SensorId } from "./types";

export const DURATION = 180;
export const DT = 0.5;
export const WORLD_W = 1100;
export const WORLD_H = 780;
export const PROFILE = "riverbend-survey-a";
export const BUILD = "nexus-fusion 0.4.0-poc";
export const CLOCK_QUARANTINE_MS = 400;

export const DEFAULT_FAULTS: Faults = {
  irBOccluded: false,
  irSaturation: false,
  irBoresight: false,
  clockOffsetMs: 0,
  gnssLoss: false,
  sarLowCoherence: false,
  linkLoss: false,
  duplicateInject: false,
};

export interface Preset {
  id: string;
  label: string;
  note: string;
  faults: Faults;
}

export const PRESETS: Preset[] = [
  {
    id: "nominal",
    label: "Nominal pass",
    note: "Calibration, clock, and GNSS inside the assumed error budget.",
    faults: { ...DEFAULT_FAULTS },
  },
  {
    id: "cal",
    label: "Calibration drift",
    note: "IR boresight expired. Biased IR returns are withheld from the merge.",
    faults: { ...DEFAULT_FAULTS, irBoresight: true },
  },
  {
    id: "gnss",
    label: "GNSS loss",
    note: "Shared pose error dominates. Naive fusion looks tighter than it is.",
    faults: { ...DEFAULT_FAULTS, gnssLoss: true },
  },
  {
    id: "clock",
    label: "Clock offset",
    note: "IR time base slips past 400 ms and is quarantined.",
    faults: { ...DEFAULT_FAULTS, clockOffsetMs: 700 },
  },
  {
    id: "link",
    label: "SAR link loss",
    note: "SAR products arrive stale and are kept out of the current picture.",
    faults: { ...DEFAULT_FAULTS, linkLoss: true, sarLowCoherence: true },
  },
  {
    id: "split",
    label: "IR withheld",
    note: "Expired IR calibration plus a mild clock slip. Geometry stays with EO and LiDAR.",
    faults: { ...DEFAULT_FAULTS, irBoresight: true, clockOffsetMs: 180 },
  },
];

export interface SensorSpec {
  id: SensorId;
  family: SensorFamily;
  range: number;
  sigma: number;
  latency: number;
  label: string;
  stage: "sensor" | "sar_product" | "navigation";
  calibrationId: string;
}

export const DETECTORS: SensorSpec[] = [
  {
    id: "LWIR-A",
    family: "lwir",
    range: 175,
    sigma: 8,
    latency: 0.35,
    label: "LWIR module A",
    stage: "sensor",
    calibrationId: "CAL-IR-2026-014",
  },
  {
    id: "LWIR-B",
    family: "lwir",
    range: 175,
    sigma: 8,
    latency: 0.35,
    label: "LWIR module B",
    stage: "sensor",
    calibrationId: "CAL-IR-2026-014",
  },
  {
    id: "EO",
    family: "eo",
    range: 190,
    sigma: 6.5,
    latency: 0.3,
    label: "Visible EO",
    stage: "sensor",
    calibrationId: "CAL-EO-2026-006",
  },
  {
    id: "SAR",
    family: "sar",
    range: 240,
    sigma: 12,
    latency: 2.6,
    label: "SAR product",
    stage: "sar_product",
    calibrationId: "CAL-SAR-PROD-2026-003",
  },
  {
    id: "LIDAR",
    family: "lidar",
    range: 130,
    sigma: 2.6,
    latency: 0.45,
    label: "LiDAR",
    stage: "sensor",
    calibrationId: "CAL-LDR-2026-009",
  },
  {
    id: "MS",
    family: "ms",
    range: 160,
    sigma: 10,
    latency: 0.5,
    label: "Multispectral",
    stage: "sensor",
    calibrationId: "CAL-MS-2026-004",
  },
  {
    id: "RF",
    family: "rf",
    range: 480,
    sigma: 75,
    latency: 0.8,
    label: "Passive RF",
    stage: "sensor",
    calibrationId: "CAL-RF-2026-002",
  },
];

export interface TruthObject {
  id: string;
  name: string;
  required: boolean;
  x: (t: number) => number;
  y: (t: number) => number;
  signatures: Partial<Record<SensorFamily, number>>;
  reads: Partial<Record<SensorFamily, { label: ClassLabel; confidence: number }>>;
}

export const TRUTHS: TruthObject[] = [
  {
    id: "bridge",
    name: "Bridge joint B-14",
    required: true,
    x: () => 640,
    y: () => 400,
    signatures: { lwir: 0.9, eo: 0.62, sar: 0.74, lidar: 0.86, ms: 0.22 },
    reads: {
      lwir: { label: "thermal anomaly", confidence: 0.78 },
      eo: { label: "structural edge", confidence: 0.6 },
      sar: { label: "structural edge", confidence: 0.7 },
      lidar: { label: "elevation change", confidence: 0.58 },
      ms: { label: "visual change", confidence: 0.28 },
    },
  },
  {
    id: "washout",
    name: "Road washout W-03",
    required: true,
    x: () => 280,
    y: () => 360,
    signatures: { lwir: 0.55, eo: 0.84, sar: 0.9, lidar: 0.8, ms: 0.7 },
    reads: {
      lwir: { label: "cool wet surface", confidence: 0.6 },
      eo: { label: "visual change", confidence: 0.74 },
      sar: { label: "surface disruption", confidence: 0.82 },
      lidar: { label: "elevation change", confidence: 0.7 },
      ms: { label: "moisture index", confidence: 0.66 },
    },
  },
  {
    id: "substation",
    name: "Substation yard S-02",
    required: true,
    x: () => 880,
    y: () => 610,
    signatures: { lwir: 0.95, eo: 0.58, sar: 0.42, lidar: 0.72 },
    reads: {
      lwir: { label: "thermal anomaly", confidence: 0.86 },
      eo: { label: "structural edge", confidence: 0.5 },
      sar: { label: "structural edge", confidence: 0.36 },
      lidar: { label: "elevation change", confidence: 0.52 },
    },
  },
  {
    id: "debris",
    name: "Debris raft D-07",
    required: true,
    x: (t) => 400 + t * 0.85,
    y: (t) => 455 + Math.sin(t * 0.07) * 16,
    signatures: { lwir: 0.28, eo: 0.76, sar: 0.4, lidar: 0.84 },
    reads: {
      lwir: { label: "visual change", confidence: 0.3 },
      eo: { label: "visual change", confidence: 0.68 },
      sar: { label: "surface disruption", confidence: 0.4 },
      lidar: { label: "elevation change", confidence: 0.72 },
    },
  },
  {
    id: "seep",
    name: "Levee seep L-11",
    required: true,
    x: () => 760,
    y: () => 290,
    signatures: { lwir: 0.66, eo: 0.34, sar: 0.48, ms: 0.92, lidar: 0.3 },
    reads: {
      lwir: { label: "cool wet surface", confidence: 0.64 },
      eo: { label: "visual change", confidence: 0.32 },
      sar: { label: "surface disruption", confidence: 0.4 },
      ms: { label: "moisture index", confidence: 0.84 },
      lidar: { label: "elevation change", confidence: 0.26 },
    },
  },
  {
    id: "culvert",
    name: "Canopy culvert C-4",
    required: true,
    x: () => 530,
    y: () => 520,
    signatures: { lwir: 0.34, sar: 0.28, lidar: 0.48, eo: 0.18 },
    reads: {
      lwir: { label: "thermal anomaly", confidence: 0.34 },
      sar: { label: "structural edge", confidence: 0.26 },
      lidar: { label: "elevation change", confidence: 0.46 },
      eo: { label: "visual change", confidence: 0.2 },
    },
  },
  {
    id: "glint",
    name: "Sun glint (clutter)",
    required: false,
    x: () => 470,
    y: () => 250,
    signatures: { eo: 0.9 },
    reads: { eo: { label: "bright transient", confidence: 0.84 } },
  },
  {
    id: "rf",
    name: "Staging-area spectrum",
    required: false,
    x: () => 190,
    y: () => 640,
    signatures: { rf: 0.95 },
    reads: { rf: { label: "spectrum activity", confidence: 0.9 } },
  },
];

const LEGS = [620, 500, 380, 260];
const leg = (i: number): number => LEGS[Math.min(Math.max(i, 0), LEGS.length - 1)]!;
const X0 = 150;
const X1 = 980;
const LEG_DUR = 36;
const TURN_DUR = 8;

export function poseAt(t: number): {
  x: number;
  y: number;
  heading: number;
  alt: number;
  speed: number;
  vx: number;
  vy: number;
} {
  const clamped = Math.min(Math.max(t, 0), DURATION);
  let rem = clamped;
  for (let i = 0; i < LEGS.length; i++) {
    const dir = i % 2 === 0 ? 1 : -1;
    if (rem <= LEG_DUR || i === LEGS.length - 1) {
      const u = Math.min(rem / LEG_DUR, 1);
      const x = dir === 1 ? X0 + (X1 - X0) * u : X1 - (X1 - X0) * u;
      const speed = (X1 - X0) / LEG_DUR;
      return {
        x,
        y: leg(i),
        heading: dir === 1 ? Math.PI / 2 : (3 * Math.PI) / 2,
        alt: 92,
        speed,
        vx: dir === 1 ? speed : -speed,
        vy: 0,
      };
    }
    rem -= LEG_DUR;
    if (i < LEGS.length - 1) {
      if (rem <= TURN_DUR) {
        const u = rem / TURN_DUR;
        const y = leg(i) + (leg(i + 1) - leg(i)) * u;
        const x = dir === 1 ? X1 : X0;
        const speed = Math.abs(leg(i + 1) - leg(i)) / TURN_DUR;
        return {
          x,
          y,
          heading: Math.PI,
          alt: 92,
          speed,
          vx: 0,
          vy: leg(i + 1) < leg(i) ? -speed : speed,
        };
      }
      rem -= TURN_DUR;
    }
  }
  return {
    x: X0,
    y: leg(LEGS.length - 1),
    heading: (3 * Math.PI) / 2,
    alt: 92,
    speed: 0,
    vx: 0,
    vy: 0,
  };
}

export function bodyRight(heading: number): { x: number; y: number } {
  return { x: Math.cos(heading), y: -Math.sin(heading) };
}

export function hashUnit(seed: string): number {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) / 4294967296;
}

export function gauss(seed: string): number {
  const u = Math.max(hashUnit(seed + ":u"), 1e-8);
  const v = hashUnit(seed + ":v");
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

export function poseSigmaAt(t: number, faults: Faults): number {
  if (!faults.gnssLoss) return 4.4;
  return Math.min(34, 8 + t * 0.14);
}

export function poseErrorAt(t: number, faults: Faults): { ex: number; ey: number; sigma: number } {
  const bucket = Math.round(t * 2) / 2;
  const sigma = poseSigmaAt(t, faults);
  return {
    ex: gauss(`pose:${bucket}:x`) * sigma,
    ey: gauss(`pose:${bucket}:y`) * sigma,
    sigma,
  };
}

const COMPAT: Record<ClassLabel, ClassLabel[]> = {
  "thermal anomaly": ["thermal anomaly", "structural edge", "elevation change", "visual change"],
  "cool wet surface": [
    "cool wet surface",
    "moisture index",
    "surface disruption",
    "visual change",
    "elevation change",
  ],
  "surface disruption": [
    "surface disruption",
    "elevation change",
    "visual change",
    "cool wet surface",
    "moisture index",
    "structural edge",
  ],
  "elevation change": [
    "elevation change",
    "structural edge",
    "surface disruption",
    "visual change",
    "thermal anomaly",
    "cool wet surface",
  ],
  "moisture index": ["moisture index", "cool wet surface", "surface disruption", "visual change"],
  "visual change": [
    "visual change",
    "structural edge",
    "elevation change",
    "surface disruption",
    "cool wet surface",
    "thermal anomaly",
    "moisture index",
  ],
  "structural edge": [
    "structural edge",
    "elevation change",
    "thermal anomaly",
    "visual change",
    "surface disruption",
  ],
  "bright transient": ["bright transient"],
  "spectrum activity": ["spectrum activity"],
  "navigation fix": ["navigation fix"],
};

export function labelsCompatible(a: ClassLabel, b: ClassLabel): boolean {
  return COMPAT[a].includes(b);
}

export function faultsActive(faults: Faults): boolean {
  return (
    faults.irBOccluded ||
    faults.irSaturation ||
    faults.irBoresight ||
    faults.clockOffsetMs > 0 ||
    faults.gnssLoss ||
    faults.sarLowCoherence ||
    faults.linkLoss ||
    faults.duplicateInject
  );
}
