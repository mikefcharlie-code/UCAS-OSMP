import { create } from "zustand";
import { frameIndex, buildTimeline } from "./fusion";
import { DEFAULT_FAULTS, DURATION, faultsActive } from "./model";
import type { Faults, FrameSnapshot, Timeline } from "./types";

export interface AuditEntry {
  id: string;
  t: number;
  trackId: string;
  rationale: string;
  action: "review" | "withhold" | "restore";
}

export interface Layers {
  lwir: boolean;
  eo: boolean;
  sar: boolean;
  lidar: boolean;
  ms: boolean;
  rf: boolean;
  fused: boolean;
  naive: boolean;
  truth: boolean;
  footprint: boolean;
}

const DEFAULT_LAYERS: Layers = {
  lwir: true,
  eo: true,
  sar: true,
  lidar: true,
  ms: false,
  rf: true,
  fused: true,
  naive: true,
  truth: true,
  footprint: true,
};

interface NexusState {
  faults: Faults;
  layers: Layers;
  timeline: Timeline;
  t: number;
  playing: boolean;
  speed: number;
  view: "map" | "pipeline" | "assurance";
  selectedTrackId: string | null;
  selectedObsId: string | null;
  audit: AuditEntry[];
  withheld: Record<string, boolean>;
  setFaults: (faults: Faults) => void;
  patchFaults: (partial: Partial<Faults>) => void;
  toggleLayer: (key: keyof Layers) => void;
  setT: (t: number) => void;
  setPlaying: (playing: boolean) => void;
  setSpeed: (speed: number) => void;
  setView: (view: NexusState["view"]) => void;
  selectTrack: (id: string | null) => void;
  selectObs: (id: string | null) => void;
  logReview: (trackId: string, rationale: string, action: AuditEntry["action"]) => void;
}

function timelineFor(faults: Faults): Timeline {
  const built = buildTimeline(faults);
  return {
    frames: built.frames,
    profile: built.profile,
    schema: built.schema,
    build: built.build,
  };
}

export const useNexus = create<NexusState>((set, get) => ({
  faults: DEFAULT_FAULTS,
  layers: DEFAULT_LAYERS,
  timeline: timelineFor(DEFAULT_FAULTS),
  t: 112,
  playing: true,
  speed: 1,
  view: "map",
  selectedTrackId: null,
  selectedObsId: null,
  audit: [],
  withheld: {},
  setFaults: (faults) => set({ faults, timeline: timelineFor(faults) }),
  patchFaults: (partial) => {
    const faults = { ...get().faults, ...partial };
    set({ faults, timeline: timelineFor(faults) });
  },
  toggleLayer: (key) => set({ layers: { ...get().layers, [key]: !get().layers[key] } }),
  setT: (t) => set({ t: Math.max(0, Math.min(DURATION, t)) }),
  setPlaying: (playing) => set({ playing }),
  setSpeed: (speed) => set({ speed }),
  setView: (view) => set({ view }),
  selectTrack: (id) => set({ selectedTrackId: id, selectedObsId: null }),
  selectObs: (id) => set({ selectedObsId: id }),
  logReview: (trackId, rationale, action) => {
    const entry: AuditEntry = {
      id: `A${get().audit.length + 1}`,
      t: get().t,
      trackId,
      rationale: rationale.trim() || "No rationale entered.",
      action,
    };
    const withheld = { ...get().withheld };
    if (action === "withhold") withheld[trackId] = true;
    if (action === "restore") delete withheld[trackId];
    set({ audit: [entry, ...get().audit].slice(0, 12), withheld });
  },
}));

export function useFrame(): FrameSnapshot {
  const timeline = useNexus((s) => s.timeline);
  const t = useNexus((s) => s.t);
  return timeline.frames[frameIndex(t, timeline.frames.length)]!;
}

export function degraded(faults: Faults): boolean {
  return faultsActive(faults);
}
