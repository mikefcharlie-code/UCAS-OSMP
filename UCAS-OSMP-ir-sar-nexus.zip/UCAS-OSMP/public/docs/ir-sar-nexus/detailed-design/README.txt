IR-SAR NEXUS DETAILED ENGINEERING DESIGN PACKAGE

Seven PDFs: subsystem specifications/budgets; interface control/data schema; architecture/drawing register; requirements traceability; simulation/test/validation; cybersecurity/safety/privacy/operations; roadmap/risk/architecture decisions.

Civilian-use scope only. Conceptual baseline, not flight-ready or certified. All requirements/budgets need validation. Platform-specific drawings, hardware selection, qualification and independent validation remain open.
